// app.js
App({
  onLaunch() {
  },
  globalData: {
    userInfo: null,
    user: {},
    url: "https://www.feisusell.cn:8200/service/"
  }
})
