// app.js
App({
  onLaunch() {
  },
  globalData: {
    userInfo: null,
    user: {},
    url: "http://localhost:8200/service/"
  }
})
