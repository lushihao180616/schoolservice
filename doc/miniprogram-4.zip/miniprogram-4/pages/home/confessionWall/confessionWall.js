var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    confessionWallList: [],
    greatList: [],
    commentList: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.request({
      url: app.globalData.url + "confession/selectLimit", //url
      method: 'POST', //请求方式
      header: {
        'Content-Type': 'application/json',
      },
      data: app.globalData.user.stuNum,
      success: function (res) {
        console.log(res.data)
        if (res.data.ifSuccess) {
          that.setData({
            confessionWallList: res.data.bean
          })
        } else {
          wx.showToast({
            title: '连接失败，请稍后再试！',
            icon: 'none',
            duration: 1500
          })
        }
      },
      fail: function () {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      },
      complete: function () {}
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    var that = this;
    wx.request({
      url: app.globalData.url + "great/insertAll", //url
      method: 'POST', //请求方式
      header: {
        'Content-Type': 'application/json',
      },
      data: JSON.stringify(that.data.greatList),
      success: function (res) {
        if (res.data.ifSuccess) {} else {
          wx.showToast({
            title: '连接失败，请稍后再试！',
            icon: 'none',
            duration: 1500
          })
        }
      },
      fail: function () {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      },
      complete: function () {}
    })
  },

  /**
   * 展示图片
   */
  showImage: function (e) {
    var urls = [];
    urls = urls.concat(e.currentTarget.dataset.src);
    wx.previewImage({
      current: e.currentTarget.dataset.src, // 当前显示图片的http链接
      urls: urls // 需要预览的图片http链接列表
    })
  },

  /**
   * 点赞
   */
  toGreat: function (e) {
    var that = this;
    var data = {};
    data.stuNum = app.globalData.user.stuNum;
    data.type = "00";
    data.typeId = e.currentTarget.dataset.id;
    var index = -1;
    for (var i = 0; i < that.data.greatList.length; i++) {
      if (that.data.greatList[i].typeId == e.currentTarget.dataset.id) {
        index = i;
      }
    }
    if (index == -1) { //不包含当前点赞，添加一个
      that.data.greatList.push(data)
    } else { //包含当前点赞
      that.data.greatList.splice(index, 1)
      that.setData({
        greatList: that.data.greatList
      })
    }
    var newConfessionWallList = [];
    that.data.confessionWallList.forEach(element => {
      var newElement = element;
      if (element.id == e.currentTarget.dataset.id) {
        if (newElement.clickGreat) {
          newElement.clickGreat = false;
          newElement.greatCount -= 1;
        } else {
          newElement.clickGreat = true
          newElement.greatCount += 1;
        }
      }
      newConfessionWallList.push(newElement)
    })
    that.setData({
      confessionWallList: newConfessionWallList
    })
  },

  /**
   * 评论
   */
  toComment: function (e) {
    var that = this
    var confessionWallId = e.currentTarget.dataset.id;

    for (var i = 0; i < that.data.confessionWallList.length; i++) {
      if (that.data.confessionWallList[i].id == confessionWallId) {
        wx.setStorage({
          data: that.data.confessionWallList[i],
          key: 'commentItem',
        })
      }
    }
    wx.navigateTo({
      url: '../comment/comment?type=00',
    })
  }
})