var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    commentList: [],

    confessionWall: null,

    modelType: '00',
    content: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var modelType = options.type;
    that.setData({
      modelType: modelType
    })
    wx.getStorage({
      key: 'commentItem',
      success: function (res) {
        if(modelType == '00'){
          that.setData({
            confessionWall: res.data
          })
          that.getComments();
        }
      }
    })
  },

  /**
   * 展示图片
   */
  showImage: function (e) {
    var urls = [];
    urls = urls.concat(e.currentTarget.dataset.src);
    wx.previewImage({
      current: e.currentTarget.dataset.src, // 当前显示图片的http链接
      urls: urls // 需要预览的图片http链接列表
    })
  },

  /**
   * 获取本条的评论信息
   */
  getComments: function () {
    var that = this;
    var type = that.data.modelType;
    var typeId = that.data.confessionWall.id;
    wx.request({
      url: app.globalData.url + "comment/selectTypeLimit", //url
      method: 'POST', //请求方式
      header: {
        'Content-Type': 'application/json',
      },
      data: {
        type: type,
        typeId: typeId
      },
      success: function (res) {
        if (res.data.ifSuccess) {
          that.setData({
            commentList: res.data.bean
          })
        } else {
          wx.showToast({
            title: '连接失败，请稍后再试！',
            icon: 'none',
            duration: 1500
          })
        }
      },
      fail: function () {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      },
      complete: function () {}
    })
  },

  getContent: function (e) {
    this.setData({
      content: e.detail.value
    })
  },

  /**
   * 发表评论
   */
  sendComment: function () {
    var that = this;
    wx.showModal({
      title: '提示',
      content: '您确定要发表评论吗？',
      success(res) {
        if (res.confirm) {
          wx.request({
            url: app.globalData.url + "comment/insertOne", //url
            method: 'POST', //请求方式
            header: {
              'Content-Type': 'application/json',
            },
            data: {
              type: that.data.modelType,
              typeId: that.data.confessionWall.id,
              stuNum: app.globalData.user.stuNum,
              content: that.data.content
            },
            success: function (res) {
              if (res.data.ifSuccess) {
                that.setData({
                  commentList: res.data.bean
                })
                wx.showToast({
                  title: '发表成功',
                  icon: 'none',
                  duration: 1500
                })
              } else {
                wx.showToast({
                  title: '连接失败，请稍后再试！',
                  icon: 'none',
                  duration: 1500
                })
              }
            },
            fail: function () {
              wx.showToast({
                title: '连接失败，请稍后再试！',
                icon: 'none',
                duration: 1500
              })
            },
            complete: function () {}
          })
        }
      }
    })
  }
})