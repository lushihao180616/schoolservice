var app = getApp()
var utils = require('../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    lostList: [],
    greatList: [],
    commentList: [],

    id: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.getLost();
  },

  getLost: function () {
    var data = {};
    data.stuNum = app.globalData.user.stuNum;
    data.id = this.data.id
    utils.toAjax(this, "lost/selectLimit", "POST", data, "getLost");
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    utils.greatSave("great/insertAll", this.data.greatList);
  },

  /**
   * 下拉刷新事件
   */
  onPullDownRefresh: function () {
    var that = this;
    that.setData({
      lostList: [],
      id: 0
    })
    that.getLost();
  },

  /**
   * 触底事件
   */
  onReachBottom: function () {
    var that = this;
    that.getLost();
  },

  /**
   * 点赞
   */
  toGreat: function (e) {
    utils.toGreat(this, app.globalData.user.stuNum, "02", e.currentTarget.dataset.id);
  },

  /**
   * 评论
   */
  toComment: function (e) {
    utils.toComment(this, "02", e.currentTarget.dataset.id);
  },

  /**
   * ajax成功
   * @param {*} res 返回参数
   * @param {*} functionName 调用函数
   */
  callBackSuccess: function (res, functionName) {
    var that = this
    if (functionName == "getLost") {
      if (res.data.ifSuccess) {
        if (res.data.bean.length > 0) {
          var nowLostList = that.data.lostList;
          res.data.bean.forEach(element => {
            nowLostList.push(element);
          });
          that.setData({
            lostList: nowLostList,
            id: res.data.bean[res.data.bean.length - 1].id
          })
        }
      } else {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      }
    }
  },

  /**
   * ajax失败
   * @param {*} functionName 调用函数
   */
  callBackFail: function (functionName) {
    var that = this
    if (functionName == "getLost") {}
  },

  /**
   * ajax完成
   * @param {*} functionName 调用函数
   */
  callBackComplete: function (functionName) {
    var that = this
    if (functionName == "getLost") {}
  }
})