var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    lostList: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.request({
      url: app.globalData.url + "lost/selectLimit", //url
      method: 'POST', //请求方式
      header: {
        'Content-Type': 'application/json',
      },
      data: {},
      success: function (res) {
        if (res.data.ifSuccess) {
          console.log(res.data.bean)
          that.setData({
            lostList: res.data.bean
          })
        } else {
          wx.showToast({
            title: '连接失败，请稍后再试！',
            icon: 'none',
            duration: 1500
          })
        }
      },
      fail: function () {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      },
      complete: function () {}
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  }
})