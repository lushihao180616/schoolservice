var app = getApp()
var utils = require('../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    marketList: [],
    greatList: [],
    commentList: [],

    id: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.getMarket();
  },

  /**
   * 获取跳蚤市场
   */
  getMarket: function () {
    var data = {};
    data.stuNum = app.globalData.user.stuNum;
    data.id = this.data.id
    utils.toAjax(this, "market/selectLimit", "POST", data, "getMarket");
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    utils.greatSave("great/insertAll", this.data.greatList);
  },

  /**
   * 下拉刷新事件
   */
  onPullDownRefresh: function () {
    var that = this;
    that.setData({
      marketList: [],
      id: 0
    })
    that.getMarket();
  },

  /**
   * 触底事件
   */
  onReachBottom: function () {
    var that = this;
    that.getMarket();
  },

  /**
   * 展示图片
   */
  showImage: function (e) {
    utils.showImage(e.currentTarget.dataset.src);
  },

  /**
   * 点赞
   */
  toGreat: function (e) {
    utils.toGreat(this, app.globalData.user.stuNum, "01", e.currentTarget.dataset.id);
  },

  /**
   * 评论
   */
  toComment: function (e) {
    utils.toComment(this, "01", e.currentTarget.dataset.id);
  },

  /**
   * ajax成功
   * @param {*} res 返回参数
   * @param {*} functionName 调用函数
   */
  callBackSuccess: function (res, functionName) {
    var that = this
    if (functionName == "getMarket") {
      if (res.data.ifSuccess) {
        if (res.data.bean.length > 0) {
          var nowMarketList = that.data.marketList;
          res.data.bean.forEach(element => {
            nowMarketList.push(element);
          });
          that.setData({
            marketList: nowMarketList,
            id: res.data.bean[res.data.bean.length - 1].id
          })
        }
      } else {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      }
    }
  },

  /**
   * ajax失败
   * @param {*} functionName 调用函数
   */
  callBackFail: function (functionName) {
    var that = this
    if (functionName == "getMarket") {}
  },

  /**
   * ajax完成
   * @param {*} functionName 调用函数
   */
  callBackComplete: function (functionName) {
    var that = this
    if (functionName == "getMarket") {}
  }
})