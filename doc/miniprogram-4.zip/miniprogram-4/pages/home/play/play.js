var app = getApp()
var utils = require('../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    playList: [],
    greatList: [],
    commentList: [],

    audioId: "",

    id: 0,
    pageLimitFlag: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.getPlay();
  },

  /**
   * 获取约玩
   */
  getPlay: function () {
    var that = this;
    if (that.data.pageLimitFlag) {
      return
    }
    that.setData({
      pageLimitFlag: true
    })
    wx.request({
      url: app.globalData.url + "play/selectLimit", //url
      method: 'POST', //请求方式
      header: {
        'Content-Type': 'application/json',
      },
      data: {
        stuNum: app.globalData.user.stuNum,
        id: that.data.id
      },
      success: function (res) {
        if (res.data.ifSuccess) {
          if (res.data.bean.length > 0) {
            var nowPlayList = that.data.playList;
            res.data.bean.forEach(element => {
              element.playAudio = false;
              nowPlayList.push(element);
            });
            that.setData({
              playList: nowPlayList,
              id: res.data.bean[res.data.bean.length - 1].id
            })
          }
        } else {
          wx.showToast({
            title: '连接失败，请稍后再试！',
            icon: 'none',
            duration: 1500
          })
        }
      },
      fail: function () {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      },
      complete: function () {
        that.setData({
          pageLimitFlag: false
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    utils.greatSave(app.globalData.url + "great/insertAll", this.data.greatList);
  },

  /**
   * 下拉刷新事件
   */
  onPullDownRefresh: function () {
    var that = this;
    that.setData({
      playList: [],
      id: 0
    })
    that.getPlay();
  },

  /**
   * 触底事件
   */
  onReachBottom: function () {
    var that = this;
    that.getPlay();
  },

  /**
   * 音频播放
   */
  audioPlay: function (e) {
    //正在播放的停掉
    wx.createAudioContext(this.data.audioId).seek(0)
    wx.createAudioContext(this.data.audioId).pause();
    //要播放的id
    var id = "myAudio" + e.currentTarget.dataset.id;
    this.setData({
      audioId: id,
    })
    var nowPlayList = [];
    this.data.playList.forEach(function (play, index) {
      if (play.id == e.currentTarget.dataset.id) {
        play.playAudio = true;
      } else {
        play.playAudio = false;
      }
      nowPlayList.push(play);
    })
    this.setData({
      playList: nowPlayList
    })
    //播放
    wx.createAudioContext(id).play()
  },

  /**
   * 音频暂停
   */
  audioPause: function (e) {
    //正在播放的停掉
    wx.createAudioContext(this.data.audioId).seek(0)
    wx.createAudioContext(this.data.audioId).pause();
    var nowPlayList = [];
    this.data.playList.forEach(function (play, index) {
      play.playAudio = false;
      nowPlayList.push(play);
    })
    this.setData({
      playList: nowPlayList
    })
  },

  /**
   * 音频播放结束
   */
  audioEnd: function () {
    var nowPlayList = [];
    this.data.playList.forEach(function (play, index) {
      play.playAudio = false;
      nowPlayList.push(play);
    })
    this.setData({
      playList: nowPlayList
    })
  },

  /**
   * 点赞
   */
  toGreat: function (e) {
    utils.toGreat(this, app.globalData.user.stuNum, "03", e.currentTarget.dataset.id);
  },

  /**
   * 评论
   */
  toComment: function (e) {
    utils.toComment(this, "03", e.currentTarget.dataset.id);
  }
})