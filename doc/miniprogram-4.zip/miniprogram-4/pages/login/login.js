var app = getApp()
var utils = require('../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    stuNum: "",
    pwd: "",
    avatarUrl: "",
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {},

  /**
   * 注册
   */
  toReg: function () {
    wx.navigateTo({
      url: 'reg/reg'
    })
  },

  /**
   * 修改
   */
  toMod: function () {
    wx.navigateTo({
      url: 'mod/mod'
    })
  },

  getStuNum: function (e) {
    this.setData({
      stuNum: e.detail.value
    })
  },

  getPwdNum: function (e) {
    this.setData({
      pwd: e.detail.value
    })
  },

  /**
   * 登录
   */
  toLogin: function () {
    var data = {};
    data.stuNum = this.data.stuNum;
    data.pwd = this.data.pwd;
    data.avatarUrl = this.data.avatarUrl;
    utils.toAjax(this, app.globalData.url + "user/checkLogin", "POST", data, "toLogin");
  },

  /**
   * ajax成功
   * @param {*} res 返回参数
   * @param {*} functionName 调用函数
   */
  callBackSuccess: function (res, functionName) {
    var that = this
    if (functionName == "toLogin") {
      if (res.data.ifSuccess) {
        app.globalData.user = res.data.bean
        wx.setStorage({
          data: res.data.bean,
          key: 'user',
        })
        wx.switchTab({
          url: '../home/home'
        })
      } else {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      }
    }
  },

  /**
   * ajax失败
   * @param {*} functionName 调用函数
   */
  callBackFail: function (functionName) {
    var that = this
    if (functionName == "toLogin") {
      wx.showToast({
        title: '连接失败，请稍后再试！',
        icon: 'none',
        duration: 1500
      })
    }
  },

  /**
   * ajax完成
   * @param {*} functionName 调用函数
   */
  callBackComplete: function (functionName) {
    var that = this
    if (functionName == "toLogin") {}
  }
})