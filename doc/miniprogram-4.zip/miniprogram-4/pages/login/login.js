const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo: {},
    stuNum: "",
    pwd: ""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.initUserInfo();
  },

  /**
   * 初始化用户信息
   */
  initUserInfo: function () {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse) {
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },

  /**
   * 获取用户信息
   */
  getUserInfo: function (e) {
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },

  /**
   * 注册
   */
  toReg: function () {
    wx.navigateTo({
      url: 'reg/reg'
    })
  },

  /**
   * 修改
   */
  toMod: function () {
    wx.navigateTo({
      url: 'mod/mod'
    })
  },

  getStuNum: function (e) {
    this.setData({
      stuNum: e.detail.value
    })
  },

  getPwdNum: function (e) {
    this.setData({
      pwd: e.detail.value
    })
  },

  toLogin: function () {
    var that = this;
    wx.request({
      url: app.globalData.url + "user/checkLogin", //url
      method: 'POST', //请求方式
      header: {
        'Content-Type': 'application/json',
      },
      data: {
        stuNum: that.data.stuNum,
        pwd: that.data.pwd,
        avatarUrl: that.data.userInfo.avatarUrl
      },
      success: function (res) {
        if (res.data.ifSuccess) {
          app.globalData.user = res.data.bean
          wx.setStorage({
            data: res.data.bean,
            key: 'user',
          }) 
          wx.switchTab({
            url: '../home/home'
          })
        } else {
          console.log("请求数据失败");
        }
      },
      fail: function () {
        console.log("请求数据失败");
      },
      complete: function () {}
    })
  }

})