var app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    sexArray: ['男', '女'],
    sexIndex: 0,
    gradeArray: ['大一', '大二', '大三', '大四', '研一', '研二', '研三'],
    gradeIndex: 0,
    dormitoryArray: [],
    dormitoryIndex: 0,

    major: "",
    className: "",
    stuNum: "",
    name: "",
    pwd: "",
    surePwd: ""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    wx.request({
      url: app.globalData.url + "dormitory/selectAll", //url
      method: 'POST', //请求方式
      header: {
        'Content-Type': 'application/json',
      },
      data: {},
      success: function (res) {
        if (res.data.ifSuccess) {
          that.setData({
            dormitoryArray: res.data.bean
          })
        } else {
          console.log("请求数据失败");
        }
      },
      fail: function () {
        console.log("请求数据失败");
      },
      complete: function () {}
    })
  },

  getMajor: function (e) {
    this.setData({
      major: e.detail.value
    })
  },

  getClassName: function (e) {
    this.setData({
      className: e.detail.value
    })
  },

  getStuNum: function (e) {
    this.setData({
      stuNum: e.detail.value
    })
  },

  getName: function (e) {
    this.setData({
      name: e.detail.value
    })
  },

  getPwd: function (e) {
    this.setData({
      pwd: e.detail.value
    })
  },

  getSurePwd: function (e) {
    this.setData({
      surePwd: e.detail.value
    })
  },

  sexChange: function (e) {
    this.setData({
      sexIndex: e.detail.value
    })
  },

  gradeChange: function (e) {
    this.setData({
      gradeIndex: e.detail.value
    })
  },

  dormitoryChange: function (e) {
    this.setData({
      dormitoryIndex: e.detail.value
    })
  },

  toReg: function () {
    var that = this;
    if (this.data.pwd != this.data.surePwd) {
      wx.showToast({
        title: '两次输入的密码不一致',
        icon: 'none',
        duration: 1500
      })
      return
    }
    wx.request({
      url: app.globalData.url + "user/reg", //url
      method: 'POST', //请求方式
      header: {
        'Content-Type': 'application/json',
      },
      data: {
        major: that.data.major,
        className: that.data.className,
        stuNum: that.data.stuNum,
        name: that.data.name,
        pwd: that.data.pwd,
        sex: this.data.sexArray[this.data.sexIndex] == '男' ? 0 : 1,
        grade: this.data.gradeArray[this.data.gradeIndex]
      },
      success: function (res) {
        wx.navigateBack({
          delta: 1,
        })
        wx.showToast({
          title: '注册成功',
          icon: 'none',
          duration: 1500
        })
      },
      fail: function () {
        console.log("请求数据失败");
      },
      complete: function () {}
    })
  }

})