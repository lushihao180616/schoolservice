var app = getApp()
var utils = require('../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    sexArray: ['男', '女'],
    sexIndex: 0,
    gradeArray: ['大一', '大二', '大三', '大四', '研一', '研二', '研三'],
    gradeIndex: 0,
    dormitoryArray: [],
    dormitoryIndex: 0,

    major: "",
    className: "",
    stuNum: "",
    name: "",
    pwd: "",
    surePwd: ""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var data = {};
    utils.toAjax(this, app.globalData.url + "dormitory/selectAll", "POST", data, "onLoad");
  },

  getMajor: function (e) {
    this.setData({
      major: e.detail.value
    })
  },

  getClassName: function (e) {
    this.setData({
      className: e.detail.value
    })
  },

  getStuNum: function (e) {
    this.setData({
      stuNum: e.detail.value
    })
  },

  getName: function (e) {
    this.setData({
      name: e.detail.value
    })
  },

  getPwd: function (e) {
    this.setData({
      pwd: e.detail.value
    })
  },

  getSurePwd: function (e) {
    this.setData({
      surePwd: e.detail.value
    })
  },

  sexChange: function (e) {
    this.setData({
      sexIndex: e.detail.value
    })
  },

  gradeChange: function (e) {
    this.setData({
      gradeIndex: e.detail.value
    })
  },

  dormitoryChange: function (e) {
    this.setData({
      dormitoryIndex: e.detail.value
    })
  },

  toReg: function () {
    if (this.data.pwd != this.data.surePwd) {
      wx.showToast({
        title: '两次输入的密码不一致',
        icon: 'none',
        duration: 1500
      })
      return
    }
    var data = {};
    data.major = this.data.major;
    data.className = this.data.className;
    data.stuNum = this.data.stuNum;
    data.name = this.data.name;
    data.pwd = this.data.pwd;
    data.sex = this.data.sexArray[this.data.sexIndex] == '男' ? 0 : 1;
    data.grade = this.data.gradeArray[this.data.gradeIndex];
    data.dormitoryId = this.data.dormitoryArray[this.data.dormitoryIndex].id;
    utils.toAjax(this, app.globalData.url + "user/reg", "POST", data, "toReg");
  },

  /**
   * ajax成功
   * @param {*} res 返回参数
   * @param {*} functionName 调用函数
   */
  callBackSuccess: function (res, functionName) {
    var that = this
    if (functionName == "onLoad") {
      if (res.data.ifSuccess) {
        that.setData({
          dormitoryArray: res.data.bean
        })
      } else {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      }
    } else if (functionName == "toReg") {
      if (res.data.ifSuccess) {
        wx.navigateBack({
          delta: 1,
        })
        wx.showToast({
          title: '注册成功',
          icon: 'none',
          duration: 1500
        })
      } else {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      }
    }
  },

  /**
   * ajax失败
   * @param {*} functionName 调用函数
   */
  callBackFail: function (functionName) {
    var that = this
    if (functionName == "onLoad") {
      wx.showToast({
        title: '连接失败，请稍后再试！',
        icon: 'none',
        duration: 1500
      })
    } else if (functionName == "toReg") {}
  },

  /**
   * ajax完成
   * @param {*} functionName 调用函数
   */
  callBackComplete: function (functionName) {
    var that = this
    if (functionName == "onLoad") {} else if (functionName == "toReg") {}
  }

})