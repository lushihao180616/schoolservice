var app = getApp()
var utils = require('../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    stuNum: "",
    oldPwd: "",
    pwd: "",
    surePwd: ""
  },

  getStuNum: function (e) {
    this.setData({
      stuNum: e.detail.value
    })
  },

  getOldPwd: function (e) {
    this.setData({
      oldPwd: e.detail.value
    })
  },

  getPwd: function (e) {
    this.setData({
      pwd: e.detail.value
    })
  },

  getSurePwd: function (e) {
    this.setData({
      surePwd: e.detail.value
    })
  },

  toMod: function () {
    if (this.data.pwd != this.data.surePwd) {
      wx.showToast({
        title: '两次输入的密码不一致',
        icon: 'none',
        duration: 1500
      })
      return
    }
    var data = {};
    data.stuNum = this.data.stuNum;
    data.pwd = this.data.pwd;
    data.oldPwd = this.data.oldPwd;
    utils.toAjax(this, app.globalData.url + "user/mod", "POST", data, "toMod");
  },

  /**
   * ajax成功
   * @param {*} res 返回参数
   * @param {*} functionName 调用函数
   */
  callBackSuccess: function (res, functionName) {
    var that = this
    if (functionName == "toMod") {
      if (res.data.ifSuccess) {
        wx.navigateBack({
          delta: 1,
        })
        wx.showToast({
          title: '修改成功',
          icon: 'none',
          duration: 1500
        })
      } else {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      }
    }
  },

  /**
   * ajax失败
   * @param {*} functionName 调用函数
   */
  callBackFail: function (functionName) {
    var that = this
    if (functionName == "toMod") {
      wx.showToast({
        title: '连接失败，请稍后再试！',
        icon: 'none',
        duration: 1500
      })
    }
  },

  /**
   * ajax完成
   * @param {*} functionName 调用函数
   */
  callBackComplete: function (functionName) {
    var that = this
    if (functionName == "toMod") {}
  }
})