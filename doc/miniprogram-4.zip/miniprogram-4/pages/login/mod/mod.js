var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    stuNum: "",
    oldPwd: "",
    pwd: "",
    surePwd: ""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  getStuNum: function (e) {
    this.setData({
      stuNum: e.detail.value
    })
  },

  getOldPwd: function (e) {
    this.setData({
      oldPwd: e.detail.value
    })
  },

  getPwd: function (e) {
    this.setData({
      pwd: e.detail.value
    })
  },

  getSurePwd: function (e) {
    this.setData({
      surePwd: e.detail.value
    })
  },

  toMod: function () {
    var that = this;
    if(this.data.pwd != this.data.surePwd){
      wx.showToast({
        title: '两次输入的密码不一致',
        icon: 'none',
        duration: 1500
      })
      return
    }
    wx.request({
      url: app.globalData.url + "user/mod", //url
      method: 'POST', //请求方式
      header: {
        'Content-Type': 'application/json',
      },
      data: {
        stuNum: that.data.stuNum,
        pwd:  that.data.pwd,
        oldPwd: that.data.oldPwd
      },
      success: function (res) {
        wx.navigateBack({
          delta: 1,
        })
        wx.showToast({
          title: '修改成功',
          icon: 'none',
          duration: 1500
        })
      },
      fail: function () {
        console.log("请求数据失败");
      },
      complete: function () {}
    })
  }
})