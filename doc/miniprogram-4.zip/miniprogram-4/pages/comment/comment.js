var app = getApp()
var utils = require('../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    commentList: [],

    confessionWall: null,
    market: null,
    lost: null,
    play: null,

    modelType: '00',
    content: '',

    audioId: ""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var modelType = options.type;
    that.setData({
      modelType: modelType
    })
    wx.getStorage({
      key: 'commentItem',
      success: function (res) {
        if (modelType == '00') {
          that.setData({
            confessionWall: res.data
          })
        }
        if (modelType == '01') {
          that.setData({
            market: res.data
          })
        }
        if (modelType == '02') {
          that.setData({
            lost: res.data
          })
        }
        if (modelType == '03') {
          that.setData({
            play: res.data
          })
        }
        that.getComments();
      }
    })
  },

  /**
   * 展示图片
   */
  showImage: function (e) {
    var urls = [];
    urls = urls.concat(e.currentTarget.dataset.src);
    wx.previewImage({
      current: e.currentTarget.dataset.src, // 当前显示图片的http链接
      urls: urls // 需要预览的图片http链接列表
    })
  },

  /**
   * 获取本条的评论信息
   */
  getComments: function () {
    var that = this;
    var type = that.data.modelType;
    var typeId;
    if (type == '00') {
      typeId = that.data.confessionWall.id;
    } else if (type == '01') {
      typeId = that.data.market.id;
    } else if (type == '02') {
      typeId = that.data.lost.id;
    } else if (type == '03') {
      typeId = that.data.play.id;
    }
    var data = {};
    data.type = type;
    data.typeId = typeId;
    utils.toAjax(this, app.globalData.url + "comment/selectTypeLimit", "POST", data, "getComments");
  },

  getContent: function (e) {
    this.setData({
      content: e.detail.value
    })
  },

  /**
   * 发表评论
   */
  sendComment: function () {
    var that = this;
    var type = that.data.modelType;
    var typeId;
    if (type == '00') {
      typeId = that.data.confessionWall.id;
    } else if (type == '01') {
      typeId = that.data.market.id;
    } else if (type == '02') {
      typeId = that.data.lost.id;
    } else if (type == '03') {
      typeId = that.data.play.id;
    }
    if (that.data.content != '' || that.data.content != null) {
      wx.showModal({
        title: '提示',
        content: '您确定要发表评论吗？',
        success(res) {
          if (res.confirm) {
            var data = {};
            data.type = type;
            data.typeId = typeId;
            data.stuNum = app.globalData.user.stuNum;
            data.content = that.data.content;
            utils.toAjax(that, app.globalData.url + "comment/insertOne", "POST", data, "sendComment");
          }
        }
      })
    }
  },

  /**
   * 音频播放
   */
  audioPlay: function (e) {
    //正在播放的停掉
    wx.createAudioContext(this.data.audioId).seek(0)
    wx.createAudioContext(this.data.audioId).pause();
    //要播放的id
    var id = "myAudio" + e.currentTarget.dataset.id;
    this.setData({
      audioId: id,
    })
    var nowPlayList = [];
    this.data.playList.forEach(function (play, index) {
      if (play.id == e.currentTarget.dataset.id) {
        play.playAudio = true;
      } else {
        play.playAudio = false;
      }
      nowPlayList.push(play);
    })
    this.setData({
      playList: nowPlayList
    })
    //播放
    wx.createAudioContext(id).play()
  },

  /**
   * 音频暂停
   */
  audioPause: function (e) {
    //正在播放的停掉
    wx.createAudioContext(this.data.audioId).seek(0)
    wx.createAudioContext(this.data.audioId).pause();
    var nowPlayList = [];
    this.data.playList.forEach(function (play, index) {
      play.playAudio = false;
      nowPlayList.push(play);
    })
    this.setData({
      playList: nowPlayList
    })
    wx.createCon
  },

  /**
   * 音频播放结束
   */
  audioEnd: function () {
    var nowPlayList = [];
    this.data.playList.forEach(function (play, index) {
      play.playAudio = false;
      nowPlayList.push(play);
    })
    this.setData({
      playList: nowPlayList
    })
  },

  /**
   * ajax成功
   * @param {*} res 返回参数
   * @param {*} functionName 调用函数
   */
  callBackSuccess: function (res, functionName) {
    var that = this
    if (functionName == "getComments") {
      if (res.data.ifSuccess) {
        that.setData({
          commentList: res.data.bean
        })
      } else {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      }
    } else if (functionName == "sendComment") {
      if (res.data.ifSuccess) {
        that.setData({
          commentList: res.data.bean,
          content: ""
        })
        wx.showToast({
          title: '发表成功',
          icon: 'none',
          duration: 1500
        })
      } else {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      }
    }
  },

  /**
   * ajax失败
   * @param {*} functionName 调用函数
   */
  callBackFail: function (functionName) {
    var that = this
    if (functionName == "getComments") {
      wx.showToast({
        title: '连接失败，请稍后再试！',
        icon: 'none',
        duration: 1500
      })
    } else if (functionName == "sendComment") {}
  },

  /**
   * ajax完成
   * @param {*} functionName 调用函数
   */
  callBackComplete: function (functionName) {
    var that = this
    if (functionName == "getComments") {} else if (functionName == "sendComment") {}
  }
})