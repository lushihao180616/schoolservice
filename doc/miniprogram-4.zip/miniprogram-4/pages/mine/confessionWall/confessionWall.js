var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    confessionWallList: [],
    user: {}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.getStorage({
      key: 'user',
      success: function (res) {
        that.setData({
          user: res.data
        })
        wx.request({
          url: app.globalData.url + "confession/selectMyLimit", //url
          method: 'POST', //请求方式
          header: {
            'Content-Type': 'application/json',
          },
          data: {
            stuNum: that.data.user.stuNum
          },
          success: function (res) {
            if (res.data.ifSuccess) {
              console.log(res.data.bean)
              that.setData({
                confessionWallList: res.data.bean
              })
            } else {
              wx.showToast({
                title: '连接失败，请稍后再试！',
                icon: 'none',
                duration: 1500
              })
            }
          },
          fail: function () {
            wx.showToast({
              title: '连接失败，请稍后再试！',
              icon: 'none',
              duration: 1500
            })
          },
          complete: function () {}
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {},

  /**
   * 展示图片
   */
  showImage: function (e) {
    var urls = [];
    urls = urls.concat(e.currentTarget.dataset.src);
    console.log(urls);
    wx.previewImage({
      current: e.currentTarget.dataset.src, // 当前显示图片的http链接
      urls: urls // 需要预览的图片http链接列表
    })
  }
})