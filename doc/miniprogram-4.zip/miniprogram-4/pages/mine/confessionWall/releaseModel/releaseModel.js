var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    user: {},

    imgs: [],
    title: "",
    content: "",

    createConfessionId: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.getStorage({
      key: 'user',
      success: function (res) {
        that.setData({
          user: res.data
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  getTitle: function (e) {
    this.setData({
      title: e.detail.value
    })
  },

  getContent: function (e) {
    this.setData({
      content: e.detail.value
    })
  },

  /**
   * 添加图片
   */
  addImage: function () {
    var that = this;
    var imgs = this.data.imgs;
    if (imgs.length >= 1) {
      return false;
    }
    wx.chooseImage({
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        var tempFilePaths = res.tempFilePaths;
        var imgs = that.data.imgs;
        for (var i = 0; i < tempFilePaths.length; i++) {
          if (imgs.length >= 1) {
            that.setData({
              imgs: imgs
            });
            return false;
          } else {
            imgs.push(tempFilePaths[i]);
          }
        }
        that.setData({
          imgs: imgs
        });
      }
    });
  },

  /**
   * 展示图片
   */
  showImage: function (e) {
    var urls = [];
    urls = urls.concat(e.currentTarget.dataset.src);
    console.log(urls);
    wx.previewImage({
      current: e.currentTarget.dataset.src, // 当前显示图片的http链接
      urls: urls // 需要预览的图片http链接列表
    })
  },

  /**
   * 删除图片
   */
  deleteImg: function (e) {
    this.setData({
      imgs: []
    })
  },

  upload: function (createConfessionId) {
    var that = this;
    wx.uploadFile({
      url: app.globalData.url + "file/upload", //仅为示例，非真实的接口地址
      filePath: that.data.imgs[0],
      name: 'imagefile',
      formData: {
        'stuNum': that.data.user.stuNum,
        'type': '00',
        'typeId': createConfessionId
      },
      success(res) {
        var data = JSON.parse(res.data);
        if (data.ifSuccess) {
          wx.showToast({
            title: '发布成功',
            icon: 'none',
            duration: 1500
          })
          wx.navigateBack({
            delta: 1,
          })
        } else {
          wx.showToast({
            title: '连接失败，请稍后再试！',
            icon: 'none',
            duration: 1500
          })
        }
      }
    })
  },

  createConfessionWall: function () {
    var that = this;
    wx.request({
      url: app.globalData.url + "confession/insertOne", //url
      method: 'POST', //请求方式
      header: {
        'Content-Type': 'application/json',
      },
      data: {
        stuNum: that.data.user.stuNum,
        title: that.data.title,
        content: that.data.content
      },
      success: function (res) {
        if (res.data.ifSuccess) {
          if (that.data.imgs.length > 0) {
            that.upload(res.data.bean);
          } else {
            wx.showToast({
              title: '发布成功',
              icon: 'none',
              duration: 1500
            })
            wx.navigateBack({
              delta: 1,
            })
          }
        } else {
          wx.showToast({
            title: '连接失败，请稍后再试！',
            icon: 'none',
            duration: 1500
          })
        }
      },
      fail: function () {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      },
      complete: function () {}
    })
  }
})