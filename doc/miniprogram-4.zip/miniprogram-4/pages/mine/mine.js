var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo: {},
    user: {}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      userInfo: app.globalData.userInfo
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this
    that.setData({
      user: app.globalData.user
    })
    console.log(that.data.user)
  },

  modifyUserInfo: function () {
    wx.navigateTo({
      url: 'modifyInfo/modifyInfo',
    })
  },

  /**
   * 跳转表白墙
   */
  toConfessionWall: function () {
    wx.navigateTo({
      url: 'confessionWall/confessionWall',
    })
  },

  /**
   * 跳转游戏约玩
   */
  toPlay: function () {
    wx.navigateTo({
      url: 'play/play',
    })
  },

  /**
   * 跳转事务招领
   */
  toLost: function () {
    wx.navigateTo({
      url: 'lost/lost',
    })
  },

  /**
   * 跳转跳蚤市场
   */
  toMarket: function () {
    wx.navigateTo({
      url: 'market/market',
    })
  },

  /**
   * 跳转消息通知
   */
  toMessage: function () {
    wx.navigateTo({
      url: 'message/message',
    })
  },

  /**
   * 跳转快递服务
   */
  toExpress: function () {
    wx.navigateTo({
      url: 'express/express',
    })
  }
})