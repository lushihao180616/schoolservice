var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo: {},
    user: {}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    this.setData({
      userInfo: app.globalData.userInfo
    })

    wx.getStorage({
      key: 'user',
      success: function (res) {
        app.globalData.user = res.data
        that.setData({
          user: res.data
        })
      },
      fail: function () {
        wx.navigateTo({
          url: '../login/login',
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {},

  modifyUserInfo: function () {
    wx.navigateTo({
      url: 'modifyInfo/modifyInfo',
    })
  },

  /**
   * 跳转表白墙
   */
  toConfessionWall: function () {
    wx.navigateTo({
      url: 'confessionWall/confessionWall',
    })
  },

  /**
   * 跳转游戏约玩
   */
  toPlay: function () {
    wx.navigateTo({
      url: 'play/play',
    })
  },

  /**
   * 跳转事务招领
   */
  toLost: function () {
    wx.navigateTo({
      url: 'lost/lost',
    })
  },

  /**
   * 跳转跳蚤市场
   */
  toMarket: function () {
    wx.navigateTo({
      url: 'market/market',
    })
  },

  /**
   * 跳转消息通知
   */
  toMessage: function () {
    wx.navigateTo({
      url: 'message/message',
    })
  },

  /**
   * 跳转快递服务
   */
  toExpress: function () {
    wx.navigateTo({
      url: 'express/express',
    })
  }
})