var app = getApp()
var utils = require('../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    marketList: [],
    greatList: [],
    commentList: [],

    id: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.onPullDownRefresh();
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    utils.greatSave("great/insertAll", this.data.greatList);
  },

  getMarket: function () {
    var data = {};
    data.stuNum = app.globalData.user.stuNum;
    data.id = this.data.id
    utils.toAjax(this, "market/selectMyLimit", "POST", data, "getMarket");
  },

  /**
   * 下拉刷新事件
   */
  onPullDownRefresh: function () {
    var that = this;
    that.setData({
      marketList: [],
      id: 0
    })
    that.getMarket();
  },

  /**
   * 触底事件
   */
  onReachBottom: function () {
    var that = this;
    that.getMarket();
  },

  /**
   * 展示图片
   */
  showImage: function (e) {
    var urls = [];
    urls = urls.concat(e.currentTarget.dataset.src);
    wx.previewImage({
      current: e.currentTarget.dataset.src, // 当前显示图片的http链接
      urls: urls // 需要预览的图片http链接列表
    })
  },

  toReleaseModel: function () {
    wx.navigateTo({
      url: '../releaseModel/releaseModel?type=01',
    })
  },

  deleteMarket: function (e) {
    var that = this;
    wx.showModal({
      title: '删除商品提示',
      content: '确定删除吗？',
      success(res) {
        if (res.confirm) {
          var data = {};
          data.id = e.currentTarget.dataset.id
          utils.toAjax(this, "market/deleteOne", "POST", data, "deleteMarket");
        }
      }
    })
  },

  /**
   * 点赞
   */
  toGreat: function (e) {
    utils.toGreat(this, app.globalData.user.stuNum, "01", e.currentTarget.dataset.id);
  },

  /**
   * 评论
   */
  toComment: function (e) {
    utils.toComment(this, "01", e.currentTarget.dataset.id);
  },

  /**
   * ajax成功
   * @param {*} res 返回参数
   * @param {*} functionName 调用函数
   */
  callBackSuccess: function (res, functionName) {
    var that = this
    if (functionName == "getMarket") {
      if (res.data.ifSuccess) {
        if (res.data.bean.length > 0) {
          var nowMarketList = that.data.marketList;
          res.data.bean.forEach(element => {
            nowMarketList.push(element);
          });
          that.setData({
            marketList: nowMarketList,
            id: res.data.bean[res.data.bean.length - 1].id
          })
        }
      } else {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      }
    } else if (functionName == "deleteMarket") {
      if (res.data.ifSuccess) {
        wx.showToast({
          title: '删除成功',
          icon: 'none',
          duration: 1500
        })
        that.onPullDownRefresh();
      } else {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      }
    }
  },

  /**
   * ajax失败
   * @param {*} functionName 调用函数
   */
  callBackFail: function (functionName) {
    var that = this
    if (functionName == "getMarket") {} else if (functionName == "deleteMarket") {}
  },

  /**
   * ajax完成
   * @param {*} functionName 调用函数
   */
  callBackComplete: function (functionName) {
    var that = this
    if (functionName == "getMarket") {} else if (functionName == "deleteMarket") {}
  }
})