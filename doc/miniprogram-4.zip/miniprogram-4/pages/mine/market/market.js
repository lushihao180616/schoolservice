var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    marketList: [],
    user: {}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    that.setData({
      user: app.globalData.user
    })
    wx.request({
      url: app.globalData.url + "market/selectMyLimit", //url
      method: 'POST', //请求方式
      header: {
        'Content-Type': 'application/json',
      },
      data: {
        stuNum: that.data.user.stuNum
      },
      success: function (res) {
        if (res.data.ifSuccess) {
          that.setData({
            marketList: res.data.bean
          })
        } else {
          wx.showToast({
            title: '连接失败，请稍后再试！',
            icon: 'none',
            duration: 1500
          })
        }
      },
      fail: function () {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      },
      complete: function () {}
    })
  },

  /**
   * 展示图片
   */
  showImage: function (e) {
    var urls = [];
    urls = urls.concat(e.currentTarget.dataset.src);
    wx.previewImage({
      current: e.currentTarget.dataset.src, // 当前显示图片的http链接
      urls: urls // 需要预览的图片http链接列表
    })
  },

  toReleaseModel: function () {
    wx.navigateTo({
      url: 'releaseModel/releaseModel',
    })
  },

  deleteMarket: function (e) {
    var that = this;
    wx.showModal({
      title: '删除商品提示',
      content: '确定删除吗？',
      success(res) {
        if (res.confirm) {
          wx.request({
            url: app.globalData.url + "market/deleteOne", //url
            method: 'POST', //请求方式
            header: {
              'Content-Type': 'application/json',
            },
            data: {
              id: e.currentTarget.dataset.id
            },
            success: function (res) {
              if (res.data.ifSuccess) {
                wx.showToast({
                  title: '删除成功',
                  icon: 'none',
                  duration: 1500
                })
                that.onShow();
              } else {
                wx.showToast({
                  title: '连接失败，请稍后再试！',
                  icon: 'none',
                  duration: 1500
                })
              }
            },
            fail: function () {
              wx.showToast({
                title: '连接失败，请稍后再试！',
                icon: 'none',
                duration: 1500
              })
            },
            complete: function () {}
          })
        }
      }
    })
  }
})