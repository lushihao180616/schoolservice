var app = getApp()
const recorderManager = wx.getRecorderManager();
const innerAudioContext = wx.createInnerAudioContext();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    user: {},

    gameArray: ['王者荣耀', '和平精英'],
    gameIndex: 0,

    content: "",

    audioPath: "",
    audiobuttontouch: false,
    playAudio: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.setData({
      user: app.globalData.user
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  gameChange: function (e) {
    this.setData({
      gameIndex: e.detail.value
    })
  },

  getContent: function (e) {
    this.setData({
      content: e.detail.value
    })
  },

  audioTouchStart: function () {
    this.audioPause();
    var that = this;
    that.setData({
      audiobuttontouch: true
    })
    const options = {
      duration: 10000, //指定录音的时长，单位 ms
      sampleRate: 16000, //采样率
      numberOfChannels: 1, //录音通道数
      encodeBitRate: 96000, //编码码率
      format: 'mp3', //音频格式，有效值 aac/mp3
      frameSize: 50, //指定帧大小，单位 KB
    }
    recorderManager.start(options);
  },

  audioTouchEnd: function () {
    var that = this
    recorderManager.onStop(function callback(e) {
      that.setData({
        audioPath: e.tempFilePath
      })
    })
    recorderManager.stop();

    this.setData({
      audiobuttontouch: false
    })
  },

  audioPlay: function (e) {
    var that = this;
    this.setData({
      playAudio: true
    })
    innerAudioContext.src = this.data.audioPath;
    innerAudioContext.play();
    innerAudioContext.onEnded(function callback() {
      that.audioPause();
    })
  },

  audioPause: function (e) {
    this.setData({
      playAudio: false
    })
    innerAudioContext.seek(0);
    innerAudioContext.stop();
  },

  deleteAudio: function () {
    this.audioPause();
    var that = this;
    wx.showModal({
      title: '删除录音提示',
      content: '确定删除吗？',
      success(res) {
        if (res.confirm) {
          that.setData({
            audioPath: ''
          })
        }
      }
    })
  },

  upload: function (createPlayId) {
    var that = this;
    wx.uploadFile({
      url: app.globalData.url + "file/audioupload", //仅为示例，非真实的接口地址
      filePath: that.data.audioPath,
      name: 'audiofile',
      formData: {
        'stuNum': that.data.user.stuNum,
        'type': '03',
        'typeId': createPlayId
      },
      success(res) {
        var data = JSON.parse(res.data);
        if (data.ifSuccess) {
          wx.showToast({
            title: '发布成功',
            icon: 'none',
            duration: 1500
          })
          wx.navigateBack({
            delta: 1,
          })
        } else {
          wx.showToast({
            title: '连接失败，请稍后再试！',
            icon: 'none',
            duration: 1500
          })
        }
      }
    })
  },

  createPlay: function () {
    var that = this;
    wx.request({
      url: app.globalData.url + "play/insertOne", //url
      method: 'POST', //请求方式
      header: {
        'Content-Type': 'application/json',
      },
      data: {
        stuNum: that.data.user.stuNum,
        type: that.data.gameIndex,
        content: that.data.content
      },
      success: function (res) {
        if (res.data.ifSuccess) {
          if (that.data.audioPath != "") {
            that.upload(res.data.bean);
          } else {
            wx.showToast({
              title: '发布成功',
              icon: 'none',
              duration: 1500
            })
            wx.navigateBack({
              delta: 1,
            })
          }
        } else {
          wx.showToast({
            title: '连接失败，请稍后再试！',
            icon: 'none',
            duration: 1500
          })
        }
      },
      fail: function () {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      },
      complete: function () {}
    })
  }

})