var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    user: {},

    gameArray: ['王者荣耀', '和平精英'],
    gameIndex: 0,

    content: "",

    audioPath: "",
    audiobuttontouch: false,
    playAudio: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.getStorage({
      key: 'user',
      success: function (res) {
        that.setData({
          user: res.data
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  gameChange: function (e) {
    this.setData({
      gameIndex: e.detail.value
    })
  },

  getContent: function (e) {
    this.setData({
      content: e.detail.value
    })
  },

  audioTouchStart: function () {
    var that = this;
    that.setData({
      audiobuttontouch: true
    })
    wx.startRecord({
      success: function (e) {
        that.setData({
          audioPath: e.tempFilePath
        })
      },
      fail: function () {
        wx.showToast({
          title: '录音失败',
          icon: 'none',
          duration: 1500
        })
        that.audioTouchEnd()
      }
    })
    console.log(that.data.audioPath + "_start");
  },

  audioTouchEnd: function () {
    this.setData({
      audiobuttontouch: false
    })
    wx.stopRecord();
    console.log(this.data.audioPath + "_end");
  },

  audioPlay: function (e) {
    this.setData({
      playAudio: true
    })
    //播放
    wx.createAudioContext("myAudio").play()
  },

  audioPause: function (e) {
    this.setData({
      playAudio: false
    })
    //正在播放的停掉
    wx.createAudioContext("myAudio").seek(0)
    wx.createAudioContext("myAudio").pause();
  },

  deleteAudio: function () {
    var that = this;
    wx.showModal({
      title: '删除录音提示',
      content: '确定删除吗？',
      success(res) {
        if (res.confirm) {
          that.audioPause();
          that.setData({
            audioPath: ''
          })
        }
      }
    })
  },

  upload: function (createPlayId) {
    var that = this;
    wx.uploadFile({
      url: app.globalData.url + "file/imageupload", //仅为示例，非真实的接口地址
      filePath: that.data.imgs[0],
      name: 'imagefile',
      formData: {
        'stuNum': that.data.user.stuNum,
        'type': '03',
        'typeId': createPlayId
      },
      success(res) {
        var data = JSON.parse(res.data);
        if (data.ifSuccess) {
          wx.showToast({
            title: '发布成功',
            icon: 'none',
            duration: 1500
          })
          wx.navigateBack({
            delta: 1,
          })
        } else {
          wx.showToast({
            title: '连接失败，请稍后再试！',
            icon: 'none',
            duration: 1500
          })
        }
      }
    })
  },

  createPlay: function () {
    var that = this;
    wx.request({
      url: app.globalData.url + "play/insertOne", //url
      method: 'POST', //请求方式
      header: {
        'Content-Type': 'application/json',
      },
      data: {
        stuNum: that.data.user.stuNum,
        type: that.data.gameIndex,
        content: that.data.content
      },
      success: function (res) {
        if (res.data.ifSuccess) {
          console.log(res.data)
          if (that.data.audioPath != "") {
            that.upload(res.data.bean);
          } else {
            wx.showToast({
              title: '发布成功',
              icon: 'none',
              duration: 1500
            })
            wx.navigateBack({
              delta: 1,
            })
          }
        } else {
          wx.showToast({
            title: '连接失败，请稍后再试！',
            icon: 'none',
            duration: 1500
          })
        }
      },
      fail: function () {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      },
      complete: function () {}
    })
  }

})