var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    playList: [],
    user: {},

    audioId: ""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.getStorage({
      key: 'user',
      success: function (res) {
        that.setData({
          user: res.data
        })
        wx.request({
          url: app.globalData.url + "play/selectMyLimit", //url
          method: 'POST', //请求方式
          header: {
            'Content-Type': 'application/json',
          },
          data: {
            stuNum: that.data.user.stuNum
          },
          success: function (res) {
            if (res.data.ifSuccess) {
              console.log(res.data.bean)
              that.setData({
                playList: res.data.bean
              })
            } else {
              wx.showToast({
                title: '连接失败，请稍后再试！',
                icon: 'none',
                duration: 1500
              })
            }
          },
          fail: function () {
            wx.showToast({
              title: '连接失败，请稍后再试！',
              icon: 'none',
              duration: 1500
            })
          },
          complete: function () {}
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  audioPlay: function (e) {
    //正在播放的停掉
    wx.createAudioContext(this.data.audioId).pause();
    //要播放的id
    var id = "myAudio" + e.currentTarget.dataset.id;
    this.setData({
      audioId: id
    })
    //播放
    wx.createAudioContext(id).play()
  },

  audioPause: function (e) {
    var id = "myAudio" + e.currentTarget.dataset.id;
    this.setData({
      audioId: id
    })
    wx.createAudioContext(id).pause()
  },
})