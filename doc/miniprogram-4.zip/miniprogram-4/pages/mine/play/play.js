var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    playList: [],
    greatList: [],
    commentList: [],

    audioId: "",

    id: 0,
    pageLimitFlag: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.onPullDownRefresh();
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    var that = this;
    wx.request({
      url: app.globalData.url + "great/insertAll", //url
      method: 'POST', //请求方式
      header: {
        'Content-Type': 'application/json',
      },
      data: JSON.stringify(that.data.greatList),
      success: function (res) {
        if (res.data.ifSuccess) {} else {
          wx.showToast({
            title: '连接失败，请稍后再试！',
            icon: 'none',
            duration: 1500
          })
        }
      },
      fail: function () {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      },
      complete: function () {}
    })
  },

  getPlay: function () {
    var that = this;
    if (that.data.pageLimitFlag) {
      return
    }
    that.setData({
      pageLimitFlag: true
    })
    wx.request({
      url: app.globalData.url + "play/selectMyLimit", //url
      method: 'POST', //请求方式
      header: {
        'Content-Type': 'application/json',
      },
      data: {
        stuNum: app.globalData.user.stuNum,
        id: that.data.id
      },
      success: function (res) {
        if (res.data.ifSuccess) {
          if (res.data.bean.length > 0) {
            var nowPlayList = that.data.playList;
            res.data.bean.forEach(element => {
              element.playAudio = false;
              nowPlayList.push(element);
            });
            that.setData({
              playList: nowPlayList,
              id: res.data.bean[res.data.bean.length - 1].id
            })
          }
        } else {
          wx.showToast({
            title: '连接失败，请稍后再试！',
            icon: 'none',
            duration: 1500
          })
        }
      },
      fail: function () {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      },
      complete: function () {
        that.setData({
          pageLimitFlag: false
        })
      }
    })
  },

  /**
   * 下拉刷新事件
   */
  onPullDownRefresh: function () {
    var that = this;
    that.setData({
      playList: [],
      id: 0
    })
    that.getPlay();
  },

  /**
   * 触底事件
   */
  onReachBottom: function () {
    var that = this;
    that.getPlay();
  },

  audioPlay: function (e) {
    //正在播放的停掉
    wx.createAudioContext(this.data.audioId).seek(0)
    wx.createAudioContext(this.data.audioId).pause();
    //要播放的id
    var id = "myAudio" + e.currentTarget.dataset.id;
    this.setData({
      audioId: id,
    })
    var nowPlayList = [];
    this.data.playList.forEach(function (play, index) {
      if (play.id == e.currentTarget.dataset.id) {
        play.playAudio = true;
      } else {
        play.playAudio = false;
      }
      nowPlayList.push(play);
    })
    this.setData({
      playList: nowPlayList
    })
    //播放
    wx.createAudioContext(id).play()
  },

  audioPause: function (e) {
    //正在播放的停掉
    wx.createAudioContext(this.data.audioId).seek(0)
    wx.createAudioContext(this.data.audioId).pause();
    var nowPlayList = [];
    this.data.playList.forEach(function (play, index) {
      play.playAudio = false;
      nowPlayList.push(play);
    })
    this.setData({
      playList: nowPlayList
    })
  },

  audioEnd: function () {
    var nowPlayList = [];
    this.data.playList.forEach(function (play, index) {
      play.playAudio = false;
      nowPlayList.push(play);
    })
    this.setData({
      playList: nowPlayList
    })
  },

  toReleaseModel: function () {
    wx.navigateTo({
      url: 'releaseModel/releaseModel',
    })
  },

  deletePlay: function (e) {
    var that = this;
    wx.showModal({
      title: '删除游戏约玩提示',
      content: '确定删除吗？',
      success(res) {
        if (res.confirm) {
          wx.request({
            url: app.globalData.url + "play/deleteOne", //url
            method: 'POST', //请求方式
            header: {
              'Content-Type': 'application/json',
            },
            data: {
              id: e.currentTarget.dataset.id
            },
            success: function (res) {
              if (res.data.ifSuccess) {
                wx.showToast({
                  title: '删除成功',
                  icon: 'none',
                  duration: 1500
                })
                that.onPullDownRefresh();
              } else {
                wx.showToast({
                  title: '连接失败，请稍后再试！',
                  icon: 'none',
                  duration: 1500
                })
              }
            },
            fail: function () {
              wx.showToast({
                title: '连接失败，请稍后再试！',
                icon: 'none',
                duration: 1500
              })
            },
            complete: function () {}
          })
        }
      }
    })
  },

  /**
   * 点赞
   */
  toGreat: function (e) {
    var that = this;
    var data = {};
    data.stuNum = app.globalData.user.stuNum;
    data.type = "03";
    data.typeId = e.currentTarget.dataset.id;
    var index = -1;
    for (var i = 0; i < that.data.greatList.length; i++) {
      if (that.data.greatList[i].typeId == e.currentTarget.dataset.id) {
        index = i;
      }
    }
    if (index == -1) { //不包含当前点赞，添加一个
      that.data.greatList.push(data)
    } else { //包含当前点赞
      that.data.greatList.splice(index, 1)
      that.setData({
        greatList: that.data.greatList
      })
    }
    var newPlayList = [];
    that.data.playList.forEach(element => {
      var newElement = element;
      if (element.id == e.currentTarget.dataset.id) {
        if (newElement.clickGreat) {
          newElement.clickGreat = false;
          newElement.greatCount -= 1;
        } else {
          newElement.clickGreat = true
          newElement.greatCount += 1;
        }
      }
      newPlayList.push(newElement)
    })
    that.setData({
      playList: newPlayList
    })
  },

  /**
   * 评论
   */
  toComment: function (e) {
    var that = this
    var playId = e.currentTarget.dataset.id;

    for (var i = 0; i < that.data.playList.length; i++) {
      if (that.data.playList[i].id == playId) {
        wx.setStorage({
          data: that.data.playList[i],
          key: 'commentItem',
        })
      }
    }
    wx.navigateTo({
      url: '../../comment/comment?type=03',
    })
  }
})