var app = getApp()
var utils = require('../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    lostList: [],
    greatList: [],
    commentList: [],

    id: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    utils.greatSave("great/insertAll", this.data.greatList);
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.onPullDownRefresh();
  },

  getLost: function () {
    var data = {};
    data.stuNum = app.globalData.user.stuNum;
    data.id = this.data.id
    utils.toAjax(this, "lost/selectMyLimit", "POST", data, "getLost");
  },

  /**
   * 下拉刷新事件
   */
  onPullDownRefresh: function () {
    var that = this;
    that.setData({
      lostList: [],
      id: 0
    })
    that.getLost();
  },

  /**
   * 触底事件
   */
  onReachBottom: function () {
    var that = this;
    that.getLost();
  },

  toReleaseModel: function () {
    wx.navigateTo({
      url: '../releaseModel/releaseModel?type=02',
    })
  },

  deleteLost: function (e) {
    var that = this;
    wx.showModal({
      title: '删除失物招领提示',
      content: '确定删除吗？',
      success(res) {
        if (res.confirm) {
          var data = {};
          data.id = e.currentTarget.dataset.id
          utils.toAjax(this, "lost/deleteOne", "POST", data, "deleteLost");
        }
      }
    })
  },

  /**
   * 点赞
   */
  toGreat: function (e) {
    utils.toGreat(this, app.globalData.user.stuNum, "02", e.currentTarget.dataset.id);
  },

  /**
   * 评论
   */
  toComment: function (e) {
    utils.toComment(this, "02", e.currentTarget.dataset.id);
  },

  /**
   * ajax成功
   * @param {*} res 返回参数
   * @param {*} functionName 调用函数
   */
  callBackSuccess: function (res, functionName) {
    var that = this
    if (functionName == "getLost") {
      if (res.data.ifSuccess) {
        if (res.data.bean.length > 0) {
          var nowLostList = that.data.lostList;
          res.data.bean.forEach(element => {
            nowLostList.push(element);
          });
          that.setData({
            lostList: nowLostList,
            id: res.data.bean[res.data.bean.length - 1].id
          })
        }
      } else {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      }
    } else if (functionName == "deleteLost") {
      if (res.data.ifSuccess) {
        wx.showToast({
          title: '删除成功',
          icon: 'none',
          duration: 1500
        })
        that.onPullDownRefresh();
      } else {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      }
    }
  },

  /**
   * ajax失败
   * @param {*} functionName 调用函数
   */
  callBackFail: function (functionName) {
    var that = this
    if (functionName == "getLost") {} else if (functionName == "deleteLost") {}
  },

  /**
   * ajax完成
   * @param {*} functionName 调用函数
   */
  callBackComplete: function (functionName) {
    var that = this
    if (functionName == "getLost") {} else if (functionName == "deleteLost") {}
  }
})