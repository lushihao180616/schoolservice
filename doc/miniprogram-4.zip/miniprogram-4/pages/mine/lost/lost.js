var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    lostList: [],
    greatList: [],
    commentList: [],

    id: 0,
    pageLimitFlag: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    var that = this;
    wx.request({
      url: app.globalData.url + "great/insertAll", //url
      method: 'POST', //请求方式
      header: {
        'Content-Type': 'application/json',
      },
      data: JSON.stringify(that.data.greatList),
      success: function (res) {
        if (res.data.ifSuccess) {} else {
          wx.showToast({
            title: '连接失败，请稍后再试！',
            icon: 'none',
            duration: 1500
          })
        }
      },
      fail: function () {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      },
      complete: function () {}
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.onPullDownRefresh();
  },

  getLost: function () {
    var that = this;
    if (that.data.pageLimitFlag) {
      return
    }
    that.setData({
      pageLimitFlag: true
    })
    wx.request({
      url: app.globalData.url + "lost/selectMyLimit", //url
      method: 'POST', //请求方式
      header: {
        'Content-Type': 'application/json',
      },
      data: {
        stuNum: app.globalData.user.stuNum,
        id: that.data.id
      },
      success: function (res) {
        if (res.data.ifSuccess) {
          if (res.data.bean.length > 0) {
            var nowLostList = that.data.lostList;
            res.data.bean.forEach(element => {
              nowLostList.push(element);
            });
            that.setData({
              lostList: nowLostList,
              id: res.data.bean[res.data.bean.length - 1].id
            })
          }
        } else {
          wx.showToast({
            title: '连接失败，请稍后再试！',
            icon: 'none',
            duration: 1500
          })
        }
      },
      fail: function () {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      },
      complete: function () {
        that.setData({
          pageLimitFlag: false
        })
      }
    })
  },

  /**
   * 下拉刷新事件
   */
  onPullDownRefresh: function () {
    var that = this;
    that.setData({
      lostList: [],
      id: 0
    })
    that.getLost();
  },

  /**
   * 触底事件
   */
  onReachBottom: function () {
    var that = this;
    that.getLost();
  },

  toReleaseModel: function () {
    wx.navigateTo({
      url: 'releaseModel/releaseModel',
    })
  },

  deleteLost: function (e) {
    var that = this;
    wx.showModal({
      title: '删除失物招领提示',
      content: '确定删除吗？',
      success(res) {
        if (res.confirm) {
          wx.request({
            url: app.globalData.url + "lost/deleteOne", //url
            method: 'POST', //请求方式
            header: {
              'Content-Type': 'application/json',
            },
            data: {
              id: e.currentTarget.dataset.id
            },
            success: function (res) {
              if (res.data.ifSuccess) {
                wx.showToast({
                  title: '删除成功',
                  icon: 'none',
                  duration: 1500
                })
                that.onPullDownRefresh();
              } else {
                wx.showToast({
                  title: '连接失败，请稍后再试！',
                  icon: 'none',
                  duration: 1500
                })
              }
            },
            fail: function () {
              wx.showToast({
                title: '连接失败，请稍后再试！',
                icon: 'none',
                duration: 1500
              })
            },
            complete: function () {}
          })
        }
      }
    })
  },

  /**
   * 点赞
   */
  toGreat: function (e) {
    var that = this;
    var data = {};
    data.stuNum = app.globalData.user.stuNum;
    data.type = "02";
    data.typeId = e.currentTarget.dataset.id;
    var index = -1;
    for (var i = 0; i < that.data.greatList.length; i++) {
      if (that.data.greatList[i].typeId == e.currentTarget.dataset.id) {
        index = i;
      }
    }
    if (index == -1) { //不包含当前点赞，添加一个
      that.data.greatList.push(data)
    } else { //包含当前点赞
      that.data.greatList.splice(index, 1)
      that.setData({
        greatList: that.data.greatList
      })
    }
    var newLostList = [];
    that.data.lostList.forEach(element => {
      var newElement = element;
      if (element.id == e.currentTarget.dataset.id) {
        if (newElement.clickGreat) {
          newElement.clickGreat = false;
          newElement.greatCount -= 1;
        } else {
          newElement.clickGreat = true
          newElement.greatCount += 1;
        }
      }
      newLostList.push(newElement)
    })
    that.setData({
      lostList: newLostList
    })
  },

  /**
   * 评论
   */
  toComment: function (e) {
    var that = this
    var lostId = e.currentTarget.dataset.id;

    for (var i = 0; i < that.data.lostList.length; i++) {
      if (that.data.lostList[i].id == lostId) {
        wx.setStorage({
          data: that.data.lostList[i],
          key: 'commentItem',
        })
      }
    }
    wx.navigateTo({
      url: '../../comment/comment?type=02',
    })
  }
})