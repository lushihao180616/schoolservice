var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    user: {},

    place: "",
    content: "",

    date: '2021-01-01',
    time: '00:00'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.getStorage({
      key: 'user',
      success: function (res) {
        that.setData({
          user: res.data
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  getPlace: function (e) {
    this.setData({
      place: e.detail.value
    })
  },

  getContent: function (e) {
    this.setData({
      content: e.detail.value
    })
  },

  bindDateChange: function(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      date: e.detail.value
    })
  },
  
  bindTimeChange: function(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      time: e.detail.value
    })
  },

  createLost: function () {
    var that = this;
    wx.request({
      url: app.globalData.url + "lost/insertOne", //url
      method: 'POST', //请求方式
      header: {
        'Content-Type': 'application/json',
      },
      data: {
        stuNum: that.data.user.stuNum,
        place: that.data.place,
        content: that.data.content,
        getTime: that.data.date + ' ' + that.data.time + ':00'
      },
      success: function (res) {
        if (res.data.ifSuccess) {
          wx.showToast({
            title: '发布成功',
            icon: 'none',
            duration: 1500
          })
          wx.navigateBack({
            delta: 1,
          })
        } else {
          wx.showToast({
            title: '连接失败，请稍后再试！',
            icon: 'none',
            duration: 1500
          })
        }
      },
      fail: function () {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      },
      complete: function () {}
    })
  }
})