var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    user: {},

    place: "",
    count: 0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.setData({
      user: app.globalData.user
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {},

  getPlace: function (e) {
    this.setData({
      place: e.detail.value
    })
  },

  getCount: function (e) {
    this.setData({
      count: e.detail.value
    })
  },

  createExpress: function () {
    var that = this;
    wx.request({
      url: app.globalData.url + "express/insertOne", //url
      method: 'POST', //请求方式
      header: {
        'Content-Type': 'application/json',
      },
      data: {
        stuNum: that.data.user.stuNum,
        place: that.data.place,
        count: that.data.count
      },
      success: function (res) {
        if (res.data.ifSuccess) {
          wx.showToast({
            title: '发布成功',
            icon: 'none',
            duration: 1500
          })
          wx.navigateBack({
            delta: 1,
          })
        } else {
          wx.showToast({
            title: '连接失败，请稍后再试！',
            icon: 'none',
            duration: 1500
          })
        }
      },
      fail: function () {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      },
      complete: function () {}
    })
  }
})