var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    expressList: [],
    user: {}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    that.setData({
      user: app.globalData.user
    })
    wx.request({
      url: app.globalData.url + "express/selectMyLimit", //url
      method: 'POST', //请求方式
      header: {
        'Content-Type': 'application/json',
      },
      data: {
        stuNum: that.data.user.stuNum
      },
      success: function (res) {
        if (res.data.ifSuccess) {
          console.log(res.data.bean)
          that.setData({
            expressList: res.data.bean
          })
        } else {
          wx.showToast({
            title: '连接失败，请稍后再试！',
            icon: 'none',
            duration: 1500
          })
        }
      },
      fail: function () {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      },
      complete: function () {}
    })
  },

  toReleaseModel: function () {
    wx.navigateTo({
      url: 'releaseModel/releaseModel',
    })
  },

  deleteExpress: function (e) {
    var that = this;
    wx.showModal({
      title: '删除快递服务提示',
      content: '确定删除吗？',
      success(res) {
        if (res.confirm) {
          wx.request({
            url: app.globalData.url + "express/deleteOne", //url
            method: 'POST', //请求方式
            header: {
              'Content-Type': 'application/json',
            },
            data: {
              id: e.currentTarget.dataset.id
            },
            success: function (res) {
              if (res.data.ifSuccess) {
                wx.showToast({
                  title: '删除成功',
                  icon: 'none',
                  duration: 1500
                })
                that.onShow();
              } else {
                wx.showToast({
                  title: '连接失败，请稍后再试！',
                  icon: 'none',
                  duration: 1500
                })
              }
            },
            fail: function () {
              wx.showToast({
                title: '连接失败，请稍后再试！',
                icon: 'none',
                duration: 1500
              })
            },
            complete: function () {}
          })
        }
      }
    })
  }
})