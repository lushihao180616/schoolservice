var app = getApp()
var utils = require('../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    expressList: [],

    id: 0,
    pageLimitFlag: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    that.getExpress();
  },

  getExpress: function () {
    var that = this;
    if (that.data.pageLimitFlag) {
      return
    }
    that.setData({
      pageLimitFlag: true
    })
    var data = {};
    data.stuNum = app.globalData.user.stuNum
    data.id = this.data.id
    utils.toAjax(this, app.globalData.url + "express/selectMyLimit", "POST", data, "getExpress");
  },

  /**
   * 下拉刷新事件
   */
  onPullDownRefresh: function () {
    var that = this;
    that.setData({
      expressList: [],
      id: 0
    })
    that.getExpress();
  },

  /**
   * 触底事件
   */
  onReachBottom: function () {
    var that = this;
    that.getExpress();
  },

  toReleaseModel: function () {
    wx.navigateTo({
      url: 'releaseModel/releaseModel',
    })
  },

  deleteExpress: function (e) {
    var that = this;
    wx.showModal({
      title: '删除快递服务提示',
      content: '确定删除吗？',
      success(res) {
        if (res.confirm) {
          var data = {};
          data.id = e.currentTarget.dataset.id
          utils.toAjax(this, app.globalData.url + "express/deleteOne", "POST", data, "deleteExpress");
        }
      }
    })
  },

  /**
   * ajax成功
   * @param {*} res 返回参数
   * @param {*} functionName 调用函数
   */
  callBackSuccess: function (res, functionName) {
    var that = this
    if (functionName == "getExpress") {
      if (res.data.ifSuccess) {
        if (res.data.bean.length > 0) {
          var nowExpressList = that.data.expressList;
          res.data.bean.forEach(element => {
            nowExpressList.push(element);
          });
          that.setData({
            expressList: nowExpressList,
            id: res.data.bean[res.data.bean.length - 1].id
          })
        }
      } else {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      }
    } else if (functionName == "deleteExpress") {
      if (res.data.ifSuccess) {
        wx.showToast({
          title: '删除成功',
          icon: 'none',
          duration: 1500
        })
        that.onShow();
      } else {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      }
    }
  },

  /**
   * ajax失败
   * @param {*} functionName 调用函数
   */
  callBackFail: function (functionName) {
    var that = this
    if (functionName == "getExpress") {
      wx.showToast({
        title: '连接失败，请稍后再试！',
        icon: 'none',
        duration: 1500
      })
    } else if (functionName == "deleteExpress") {
      wx.showToast({
        title: '连接失败，请稍后再试！',
        icon: 'none',
        duration: 1500
      })
    }
  },

  /**
   * ajax完成
   * @param {*} functionName 调用函数
   */
  callBackComplete: function (functionName) {
    var that = this
    if (functionName == "getExpress") {
      that.setData({
        pageLimitFlag: false
      })
    } else if (functionName == "deleteExpress") {
      that.setData({
        pageLimitFlag: false
      })
    }
  }
})