var app = getApp()
const recorderManager = wx.getRecorderManager();
const innerAudioContext = wx.createInnerAudioContext();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    user: {},

    modelType: "",

    imgs: [],
    title: "",
    content: "",

    place: "",

    date: '2021-01-01',
    time: '00:00',

    gameArray: ['王者荣耀', '和平精英'],
    gameIndex: 0,

    audioPath: "",
    audiobuttontouch: false,
    playAudio: false,

    count: 0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var modelType = options.type;
    that.setData({
      user: app.globalData.user,
      modelType: modelType
    })
  },

  getTitle: function (e) {
    this.setData({
      title: e.detail.value
    })
  },

  getContent: function (e) {
    this.setData({
      content: e.detail.value
    })
  },

  getPlace: function (e) {
    this.setData({
      place: e.detail.value
    })
  },

  gameChange: function (e) {
    this.setData({
      gameIndex: e.detail.value
    })
  },

  getCount: function (e) {
    this.setData({
      count: e.detail.value
    })
  },

  /**
   * 添加图片
   */
  addImage: function () {
    var that = this;
    var imgs = this.data.imgs;
    if (imgs.length >= 1) {
      return false;
    }
    wx.chooseImage({
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        var tempFilePaths = res.tempFilePaths;
        var imgs = that.data.imgs;
        for (var i = 0; i < tempFilePaths.length; i++) {
          if (imgs.length >= 1) {
            that.setData({
              imgs: imgs
            });
            return false;
          } else {
            imgs.push(tempFilePaths[i]);
          }
        }
        that.setData({
          imgs: imgs
        });
      }
    });
  },

  /**
   * 展示图片
   */
  showImage: function (e) {
    var urls = [];
    urls = urls.concat(e.currentTarget.dataset.src);
    wx.previewImage({
      current: e.currentTarget.dataset.src, // 当前显示图片的http链接
      urls: urls // 需要预览的图片http链接列表
    })
  },

  /**
   * 删除图片
   */
  deleteImg: function (e) {
    this.setData({
      imgs: []
    })
  },

  upload: function (createModelId, type, filePath, name) {
    var that = this;
    var url;
    if (name == "imagefile") {
      url = app.globalData.url + "file/imageupload"
    } else if (name == "audiofile") {
      url = app.globalData.url + "file/audioupload"
    }
    wx.uploadFile({
      url: url, //仅为示例，非真实的接口地址
      filePath: filePath,
      name: name,
      formData: {
        'stuNum': that.data.user.stuNum,
        'type': type,
        'typeId': createModelId
      },
      success(res) {
        var data = JSON.parse(res.data);
        if (data.ifSuccess) {
          wx.showToast({
            title: '发布成功',
            icon: 'none',
            duration: 1500
          })
          wx.navigateBack({
            delta: 1,
          })
        } else {
          wx.showToast({
            title: '连接失败，请稍后再试！',
            icon: 'none',
            duration: 1500
          })
        }
      }
    })
  },

  createConfessionWall: function () {
    var that = this;
    wx.request({
      url: app.globalData.url + "confession/insertOne", //url
      method: 'POST', //请求方式
      header: {
        'Content-Type': 'application/json',
      },
      data: {
        stuNum: that.data.user.stuNum,
        title: that.data.title,
        content: that.data.content
      },
      success: function (res) {
        if (res.data.ifSuccess) {
          if (that.data.imgs.length > 0) {
            that.upload(res.data.bean, "00", that.data.imgs[0], 'imagefile');
          } else {
            wx.showToast({
              title: '发布成功',
              icon: 'none',
              duration: 1500
            })
            wx.navigateBack({
              delta: 1,
            })
          }
        } else {
          wx.showToast({
            title: '连接失败，请稍后再试！',
            icon: 'none',
            duration: 1500
          })
        }
      },
      fail: function () {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      },
      complete: function () {}
    })
  },

  bindDateChange: function (e) {
    this.setData({
      date: e.detail.value
    })
  },

  bindTimeChange: function (e) {
    this.setData({
      time: e.detail.value
    })
  },

  createLost: function () {
    var that = this;
    wx.request({
      url: app.globalData.url + "lost/insertOne", //url
      method: 'POST', //请求方式
      header: {
        'Content-Type': 'application/json',
      },
      data: {
        stuNum: that.data.user.stuNum,
        place: that.data.place,
        content: that.data.content,
        getTime: that.data.date + ' ' + that.data.time + ':00'
      },
      success: function (res) {
        if (res.data.ifSuccess) {
          wx.showToast({
            title: '发布成功',
            icon: 'none',
            duration: 1500
          })
          wx.navigateBack({
            delta: 1,
          })
        } else {
          wx.showToast({
            title: '连接失败，请稍后再试！',
            icon: 'none',
            duration: 1500
          })
        }
      },
      fail: function () {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      },
      complete: function () {}
    })
  },

  createMarket: function () {
    var that = this;
    wx.request({
      url: app.globalData.url + "market/insertOne", //url
      method: 'POST', //请求方式
      header: {
        'Content-Type': 'application/json',
      },
      data: {
        stuNum: that.data.user.stuNum,
        title: that.data.title,
        content: that.data.content
      },
      success: function (res) {
        if (res.data.ifSuccess) {
          if (that.data.imgs.length > 0) {
            that.upload(res.data.bean, "01", that.data.imgs[0], 'imagefile');
          } else {
            wx.showToast({
              title: '发布成功',
              icon: 'none',
              duration: 1500
            })
            wx.navigateBack({
              delta: 1,
            })
          }
        } else {
          wx.showToast({
            title: '连接失败，请稍后再试！',
            icon: 'none',
            duration: 1500
          })
        }
      },
      fail: function () {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      },
      complete: function () {}
    })
  },

  audioTouchStart: function () {
    this.audioPause();
    var that = this;
    that.setData({
      audiobuttontouch: true
    })
    const options = {
      duration: 10000, //指定录音的时长，单位 ms
      sampleRate: 16000, //采样率
      numberOfChannels: 1, //录音通道数
      encodeBitRate: 96000, //编码码率
      format: 'mp3', //音频格式，有效值 aac/mp3
      frameSize: 50, //指定帧大小，单位 KB
    }
    recorderManager.onStop(function callback(e) {
      that.setData({
        audioPath: e.tempFilePath
      })
    })
    recorderManager.start(options);
  },

  audioTouchEnd: function () {
    recorderManager.stop();

    this.setData({
      audiobuttontouch: false
    })
  },

  audioPlay: function (e) {
    var that = this;
    this.setData({
      playAudio: true
    })
    console.log(this.data.audioPath);
    innerAudioContext.src = this.data.audioPath;
    innerAudioContext.play();
    innerAudioContext.onEnded(function callback() {
      that.audioPause();
    })
  },

  audioPause: function (e) {
    this.setData({
      playAudio: false
    })
    innerAudioContext.seek(0);
    innerAudioContext.stop();
  },

  deleteAudio: function () {
    this.audioPause();
    var that = this;
    wx.showModal({
      title: '删除录音提示',
      content: '确定删除吗？',
      success(res) {
        if (res.confirm) {
          that.setData({
            audioPath: ''
          })
        }
      }
    })
  },

  createPlay: function () {
    var that = this;
    wx.request({
      url: app.globalData.url + "play/insertOne", //url
      method: 'POST', //请求方式
      header: {
        'Content-Type': 'application/json',
      },
      data: {
        stuNum: that.data.user.stuNum,
        type: that.data.gameIndex,
        content: that.data.content
      },
      success: function (res) {
        if (res.data.ifSuccess) {
          if (that.data.audioPath != "") {
            that.upload(res.data.bean, "03", that.data.audioPath, 'audiofile');
          } else {
            wx.showToast({
              title: '发布成功',
              icon: 'none',
              duration: 1500
            })
            wx.navigateBack({
              delta: 1,
            })
          }
        } else {
          wx.showToast({
            title: '连接失败，请稍后再试！',
            icon: 'none',
            duration: 1500
          })
        }
      },
      fail: function () {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      },
      complete: function () {}
    })
  },

  createExpress: function () {
    var that = this;
    wx.request({
      url: app.globalData.url + "express/insertOne", //url
      method: 'POST', //请求方式
      header: {
        'Content-Type': 'application/json',
      },
      data: {
        stuNum: that.data.user.stuNum,
        place: that.data.place,
        count: that.data.count
      },
      success: function (res) {
        if (res.data.ifSuccess) {
          wx.showToast({
            title: '发布成功',
            icon: 'none',
            duration: 1500
          })
          wx.navigateBack({
            delta: 1,
          })
        } else {
          wx.showToast({
            title: '连接失败，请稍后再试！',
            icon: 'none',
            duration: 1500
          })
        }
      },
      fail: function () {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      },
      complete: function () {}
    })
  }
})