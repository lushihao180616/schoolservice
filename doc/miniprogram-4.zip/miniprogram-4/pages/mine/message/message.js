var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    messageList: [],

    id: 0,
    pageLimitFlag: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    that.getMessage();
  },

  getMessage: function () {
    var that = this;
    if (that.data.pageLimitFlag) {
      return
    }
    that.setData({
      pageLimitFlag: true
    })
    wx.request({
      url: app.globalData.url + "message/selectMyLimit", //url
      method: 'POST', //请求方式
      header: {
        'Content-Type': 'application/json',
      },
      data: {
        stuNum: app.globalData.user.stuNum,
        id: that.data.id
      },
      success: function (res) {
        if (res.data.ifSuccess) {
          if (res.data.bean.length > 0) {
            var nowMessageList = that.data.messageList;
            res.data.bean.forEach(element => {
              nowMessageList.push(element);
            });
            that.setData({
              messageList: nowMessageList,
              id: res.data.bean[res.data.bean.length - 1].id
            })
          }
        } else {
          wx.showToast({
            title: '连接失败，请稍后再试！',
            icon: 'none',
            duration: 1500
          })
        }
      },
      fail: function () {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      },
      complete: function () {
        that.setData({
          pageLimitFlag: false
        })
      }
    })
  },

  /**
   * 下拉刷新事件
   */
  onPullDownRefresh: function () {
    var that = this;
    that.setData({
      messageList: [],
      id: 0
    })
    that.getMessage();
  },

  /**
   * 触底事件
   */
  onReachBottom: function () {
    var that = this;
    that.getMessage();
  },

})