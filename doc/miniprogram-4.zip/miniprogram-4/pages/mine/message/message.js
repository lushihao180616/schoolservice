var app = getApp()
var utils = require('../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    messageList: [],

    id: 0,
    pageLimitFlag: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    that.getMessage();
  },

  getMessage: function () {
    var that = this;
    if (that.data.pageLimitFlag) {
      return
    }
    that.setData({
      pageLimitFlag: true
    })
    var data = {};
    data.stuNum = app.globalData.user.stuNum;
    data.id =  this.data.id;
    utils.toAjax(this, app.globalData.url + "message/selectMyLimit", "POST", data, "getMessage");
  },

  /**
   * 下拉刷新事件
   */
  onPullDownRefresh: function () {
    var that = this;
    that.setData({
      messageList: [],
      id: 0
    })
    that.getMessage();
  },

  /**
   * 触底事件
   */
  onReachBottom: function () {
    var that = this;
    that.getMessage();
  },

  /**
   * ajax成功
   * @param {*} res 返回参数
   * @param {*} functionName 调用函数
   */
  callBackSuccess: function (res, functionName) {
    var that = this
    if (functionName == "getMessage") {
      if (res.data.ifSuccess) {
        if (res.data.bean.length > 0) {
          var nowMessageList = that.data.messageList;
          res.data.bean.forEach(element => {
            nowMessageList.push(element);
          });
          that.setData({
            messageList: nowMessageList,
            id: res.data.bean[res.data.bean.length - 1].id
          })
        }
      } else {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      }
    }
  },

  /**
   * ajax失败
   * @param {*} functionName 调用函数
   */
  callBackFail: function (functionName) {
    var that = this
    if (functionName == "getMessage") {
      wx.showToast({
        title: '连接失败，请稍后再试！',
        icon: 'none',
        duration: 1500
      })
    }
  },

  /**
   * ajax完成
   * @param {*} functionName 调用函数
   */
  callBackComplete: function (functionName) {
    var that = this
    if (functionName == "getMessage") {
      that.setData({
        pageLimitFlag: false
      })
    }
  }

})