var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    user: {},

    sexArray: ['男', '女'],
    sexIndex: 0,
    gradeArray: ['大一', '大二', '大三', '大四', '研一', '研二', '研三'],
    gradeIndex: 0,
    dormitoryArray: [],
    dormitoryIndex: 0,

    major: "",
    className: "",
    name: ""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  },

  onShow: function () {
    var that = this;
    that.setData({
      user: app.globalData.user
    })
    var gradeIndex = 0
    if (that.data.user.grade == '大二') {
      gradeIndex = 1
    } else if (that.data.user.grade == '大三') {
      gradeIndex = 2
    } else if (that.data.user.grade == '大四') {
      gradeIndex = 3
    } else if (that.data.user.grade == '研一') {
      gradeIndex = 4
    } else if (that.data.user.grade == '研二') {
      gradeIndex = 5
    } else if (that.data.user.grade == '研三') {
      gradeIndex = 6
    }
    that.setData({
      major: that.data.user.major,
      className: that.data.user.className,
      name: that.data.user.name,
      sexIndex: that.data.user.sex,
      gradeIndex: gradeIndex
    })
    wx.request({
      url: app.globalData.url + "dormitory/selectAll", //url
      method: 'POST', //请求方式
      header: {
        'Content-Type': 'application/json',
      },
      data: {},
      success: function (res) {
        if (res.data.ifSuccess) {
          that.setData({
            dormitoryArray: res.data.bean
          })
          var id = 0;
          for (var i = 0; i < that.data.dormitoryArray.length; i++) {
            if (that.data.user.dormitoryId == that.data.dormitoryArray[i].id) {
              id = i;
            }
            that.setData({
              dormitoryIndex: id
            })
          }
        } else {
          console.log("请求数据失败");
        }
      },
      fail: function () {
        console.log("请求数据失败");
      },
      complete: function () {}
    })
  },

  getMajor: function (e) {
    this.setData({
      major: e.detail.value
    })
  },

  getClassName: function (e) {
    this.setData({
      className: e.detail.value
    })
  },

  getName: function (e) {
    this.setData({
      name: e.detail.value
    })
  },

  sexChange: function (e) {
    this.setData({
      sexIndex: e.detail.value
    })
  },

  gradeChange: function (e) {
    this.setData({
      gradeIndex: e.detail.value
    })
  },

  dormitoryChange: function (e) {
    this.setData({
      dormitoryIndex: e.detail.value
    })
  },

  toModify: function () {
    var that = this;
    wx.request({
      url: app.globalData.url + "user/modifyInfo", //url
      method: 'POST', //请求方式
      header: {
        'Content-Type': 'application/json',
      },
      data: {
        major: that.data.major,
        className: that.data.className,
        stuNum: that.data.user.stuNum,
        name: that.data.name,
        sex: that.data.sexArray[that.data.sexIndex] == '男' ? 0 : 1,
        grade: that.data.gradeArray[that.data.gradeIndex],
        dormitoryId: this.data.dormitoryArray[this.data.dormitoryIndex].id
      },
      success: function (res) {
        app.globalData.user = res.data.bean
        wx.setStorage({
          data: res.data.bean,
          key: 'user',
        })
        wx.navigateBack({
          delta: 1,
        })
      },
      fail: function () {
        console.log("请求数据失败");
      },
      complete: function () {}
    })
  }
})