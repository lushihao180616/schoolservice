module.exports = {
  greatSave: greatSave,
  toGreat: toGreat,
  toComment: toComment,
  toAjax: toAjax,
  audioPlay: audioPlay,
  audioPause: audioPause,
  audioEnd: audioEnd
}

/**
 * 是否可继续请求
 */
var pageLimitFlag = false;
/**
 * 请求公共地址
 */
var commenUrl = "http://localhost:8200/service/";

/**
 * 离开页面时保存点赞信息
 * @param {*} url 
 * @param {*} greatList 
 */
function greatSave(url, greatList) {
  wx.request({
    url: commenUrl + url, //url
    method: 'POST', //请求方式
    header: {
      'Content-Type': 'application/json',
    },
    data: JSON.stringify(greatList),
    success: function (res) {
      if (res.data.ifSuccess) {} else {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      }
    },
    fail: function () {
      wx.showToast({
        title: '连接失败，请稍后再试！',
        icon: 'none',
        duration: 1500
      })
    },
    complete: function () {}
  })
}

/**
 * 点击点赞按钮
 */
function toGreat(that, stuNum, type, typeId) {
  var data = {};
  data.stuNum = stuNum;
  data.type = type;
  data.typeId = typeId;
  var index = -1;
  for (var i = 0; i < that.data.greatList.length; i++) {
    if (that.data.greatList[i].typeId == typeId) {
      index = i;
    }
  }
  if (index == -1) { //不包含当前点赞，添加一个
    that.data.greatList.push(data)
  } else { //包含当前点赞
    that.data.greatList.splice(index, 1)
  }
  that.setData({
    greatList: that.data.greatList
  })
  var newModelList = [];
  var modelList;
  if (type == '03') {
    modelList = that.data.playList;
  } else if (type == '01') {
    modelList = that.data.marketList;
  } else if (type == '02') {
    modelList = that.data.lostList;
  } else if (type == '00') {
    modelList = that.dat.confessionWallList;
  }
  modelList.forEach(element => {
    var newElement = element;
    if (element.id == typeId) {
      if (newElement.clickGreat) {
        newElement.clickGreat = false;
        newElement.greatCount -= 1;
      } else {
        newElement.clickGreat = true
        newElement.greatCount += 1;
      }
    }
    newModelList.push(newElement)
  })

  if (type == '03') {
    that.setData({
      playList: newModelList
    })
  } else if (type == '01') {
    that.setData({
      marketList: newModelList
    })
  } else if (type == '02') {
    that.setData({
      lostList: newModelList
    })
  } else if (type == '00') {
    that.setData({
      confessionWallList: newModelList
    })
  }
}

/**
 * 跳转到评论页面
 */
function toComment(that, type, typeId) {
  var modelList;
  if (type == '03') {
    modelList = that.data.playList;
  } else if (type == '01') {
    modelList = that.data.marketList;
  } else if (type == '02') {
    modelList = that.data.lostList;
  } else if (type == '00') {
    modelList = that.data.confessionWallList;
  }

  for (var i = 0; i < modelList.length; i++) {
    if (modelList[i].id == typeId) {
      wx.setStorage({
        data: modelList[i],
        key: 'commentItem',
      })
    }
  }
  wx.navigateTo({
    url: '../../comment/comment?type=' + type,
  })
}

/**
 * 异步请求
 */
function toAjax(that, url, method, data, functionName) {
  if (pageLimitFlag) {
    return
  }
  pageLimitFlag = true
  wx.request({
    url: commenUrl + url, //url
    method: method, //请求方式
    header: {
      'Content-Type': 'application/json',
    },
    data: data,
    success: function (res) {
      that.callBackSuccess(res, functionName);
    },
    fail: function () {
      wx.showToast({
        title: '连接失败，请稍后再试！',
        icon: 'none',
        duration: 1500
      })
      that.callBackFail(functionName);
    },
    complete: function () {
      pageLimitFlag = false;
      that.callBackComplete(functionName);
    }
  })
}

/**
 * 音频播放
 */
function audioPlay(that, modelId) {
  //正在播放的停掉
  wx.createAudioContext(that.data.audioId).seek(0)
  wx.createAudioContext(that.data.audioId).pause();
  //要播放的id
  var id = "myAudio" + that;
  that.setData({
    audioId: id,
  })
  var nowPlayList = [];
  that.data.playList.forEach(function (play, index) {
    if (play.id == modelId) {
      play.playAudio = true;
    } else {
      play.playAudio = false;
    }
    nowPlayList.push(play);
  })
  that.setData({
    playList: nowPlayList
  })
  //播放
  wx.createAudioContext(id).play()
}

/**
 * 音频暂停
 */
function audioPause(that) {
  //正在播放的停掉
  wx.createAudioContext(that.data.audioId).seek(0)
  wx.createAudioContext(that.data.audioId).pause();
  var nowPlayList = [];
  that.data.playList.forEach(function (play, index) {
    play.playAudio = false;
    nowPlayList.push(play);
  })
  that.setData({
    playList: nowPlayList
  })
}

/**
 * 音频播放结束
 */
function audioEnd(that) {
  var nowPlayList = [];
  that.data.playList.forEach(function (play, index) {
    play.playAudio = false;
    nowPlayList.push(play);
  })
  that.setData({
    playList: nowPlayList
  })
}