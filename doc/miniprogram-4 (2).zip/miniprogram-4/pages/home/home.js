var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.getStorage({
      key: 'user',
      success: function(res) {
        app.globalData.user = res.data
      }
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  },

  /**
   * 跳转表白墙
   */
  toConfessionWall: function () {
    wx.navigateTo({
      url: 'confessionWall/confessionWall',
    })
  },

  /**
   * 跳转游戏约玩
   */
  toPlay: function () {
    wx.navigateTo({
      url: 'play/play',
    })
  },

  /**
   * 跳转事务招领
   */
  toLost: function () {
    wx.navigateTo({
      url: 'lost/lost',
    })
  },

  /**
   * 跳转跳蚤市场
   */
  toMarket: function () {
    wx.navigateTo({
      url: 'market/market',
    })
  },

  /**
   * 跳转快递服务
   */
  toExpress: function () {
    wx.navigateTo({
      url: 'express/express',
    })
  },
})