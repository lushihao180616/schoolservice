var app = getApp()
var utils = require('../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    marketList: [],
    greatList: [],
    commentList: [],

    id: 0,

    createModel: null,//添加的元素
    commentCount: 0,//评论的数量
    modelId: 0//评论的标识
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this
    //初始化数据
    if (this.data.createModel == null && this.data.modelId == 0) {
      this.onPullDownRefresh();
    }
    //新添加元素的情况，不刷新整个的数据
    if (this.data.createModel != null)  {
      var nowMarketList = that.data.marketList;
      nowMarketList.unshift(that.data.createModel);
      this.setData({
        marketList: nowMarketList,
        createModel: null
      })
    }
    //评论后的情况，不刷新整个的数据
    if (this.data.modelId != 0) {
      var nowMarketList = [];
      that.data.marketList.forEach(element => {
        if (element.id == that.data.modelId) {
          element.commentCount = that.data.commentCount
        }
        nowMarketList.push(element)
      });
      that.setData({
        marketList: nowMarketList,
        commentCount: 0,
        modelId: 0
      })
    }
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    utils.greatSave("great/insertAll", this.data.greatList);
  },

  getMarket: function () {
    var data = {};
    data.stuNum = app.globalData.user.stuNum;
    data.id = this.data.id
    utils.toAjax(this, "market/selectMyLimit", "POST", data, "getMarket");
  },

  /**
   * 下拉刷新事件
   */
  onPullDownRefresh: function () {
    var that = this;
    that.setData({
      marketList: [],
      id: 0
    })
    that.getMarket();
  },

  /**
   * 触底事件
   */
  onReachBottom: function () {
    var that = this;
    that.getMarket();
  },

  /**
   * 展示图片
   */
  showImage: function (e) {
    utils.showImage(e.currentTarget.dataset.src);
  },

  toReleaseModel: function () {
    wx.navigateTo({
      url: '../releaseModel/releaseModel?type=01',
    })
  },

  deleteMarket: function (e) {
    var that = this;
    wx.showModal({
      title: '删除商品提示',
      content: '确定删除吗？',
      success(res) {
        if (res.confirm) {
          var data = {};
          data.id = e.currentTarget.dataset.id
          utils.toAjax(that, "market/deleteOne", "POST", data, "deleteMarket");
        }
      }
    })
  },

  /**
   * 点赞
   */
  toGreat: function (e) {
    utils.toGreat(this, app.globalData.user.stuNum, "01", e.currentTarget.dataset.id);
  },

  /**
   * 评论
   */
  toComment: function (e) {
    utils.toComment(this, "01", e.currentTarget.dataset.id);
  },

  /**
   * ajax成功
   * @param {*} res 返回参数
   * @param {*} functionName 调用函数
   */
  callBackSuccess: function (res, functionName) {
    var that = this
    if (functionName == "getMarket") {
      if (res.data.ifSuccess) {
        if (res.data.bean.length > 0) {
          var nowMarketList = that.data.marketList;
          res.data.bean.forEach(element => {
            nowMarketList.push(element);
          });
          that.setData({
            marketList: nowMarketList,
            id: res.data.bean[res.data.bean.length - 1].id
          })
        }
      } else {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      }
    } else if (functionName == "deleteMarket") {
      if (res.data.ifSuccess) {
        wx.showToast({
          title: '删除成功',
          icon: 'none',
          duration: 1500
        })
        var newMarketList = [];
        that.data.marketList.forEach(element => {
          if(element.id != res.data.bean){
            newMarketList.push(element);
          }
        });
        that.setData({
          marketList: newMarketList
        })
      } else {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      }
    }
  },

  /**
   * ajax失败
   * @param {*} functionName 调用函数
   */
  callBackFail: function (functionName) {
    var that = this
    if (functionName == "getMarket") {} else if (functionName == "deleteMarket") {}
  },

  /**
   * ajax完成
   * @param {*} functionName 调用函数
   */
  callBackComplete: function (functionName) {
    var that = this
    if (functionName == "getMarket") {} else if (functionName == "deleteMarket") {}
  }
})