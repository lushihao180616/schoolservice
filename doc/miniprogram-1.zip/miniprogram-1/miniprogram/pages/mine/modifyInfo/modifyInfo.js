var app = getApp()
var utils = require('../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    user: {},

    sexArray: ['男', '女'],
    sexIndex: 0,
    gradeArray: ['大一', '大二', '大三', '大四', '研一', '研二', '研三'],
    gradeIndex: 0,
    dormitoryArray: [],
    dormitoryIndex: 0,

    major: "",
    className: "",
    name: ""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {},

  onShow: function () {
    var that = this;
    that.setData({
      user: app.globalData.user
    })
    var gradeIndex = 0
    if (that.data.user.grade == '大二') {
      gradeIndex = 1
    } else if (that.data.user.grade == '大三') {
      gradeIndex = 2
    } else if (that.data.user.grade == '大四') {
      gradeIndex = 3
    } else if (that.data.user.grade == '研一') {
      gradeIndex = 4
    } else if (that.data.user.grade == '研二') {
      gradeIndex = 5
    } else if (that.data.user.grade == '研三') {
      gradeIndex = 6
    }
    that.setData({
      major: that.data.user.major,
      className: that.data.user.className,
      name: that.data.user.name,
      sexIndex: that.data.user.sex,
      gradeIndex: gradeIndex
    })
    var data = {};
    utils.toAjax(this, "dormitory/selectAll", "POST", data, "onShow");
  },

  getMajor: function (e) {
    this.setData({
      major: e.detail.value
    })
  },

  getClassName: function (e) {
    this.setData({
      className: e.detail.value
    })
  },

  getName: function (e) {
    this.setData({
      name: e.detail.value
    })
  },

  sexChange: function (e) {
    this.setData({
      sexIndex: e.detail.value
    })
  },

  gradeChange: function (e) {
    this.setData({
      gradeIndex: e.detail.value
    })
  },

  dormitoryChange: function (e) {
    this.setData({
      dormitoryIndex: e.detail.value
    })
  },

  toModify: function () {
    var that = this;
    var data = {};
    data.major = that.data.major;
    data.className = that.data.className;
    data.stuNum = that.data.user.stuNum;
    data.name = that.data.name;
    data.sex = that.data.sexArray[that.data.sexIndex] == '男' ? 0 : 1;
    data.grade = that.data.gradeArray[that.data.gradeIndex];
    data.dormitoryId = that.data.dormitoryArray[that.data.dormitoryIndex].id;
    utils.toAjax(this, "user/modifyInfo", "POST", data, "toModify");
  },

  /**
   * ajax成功
   * @param {*} res 返回参数
   * @param {*} functionName 调用函数
   */
  callBackSuccess: function (res, functionName) {
    var that = this
    if (functionName == "onShow") {
      if (res.data.ifSuccess) {
        that.setData({
          dormitoryArray: res.data.bean
        })
        var id = 0;
        for (var i = 0; i < that.data.dormitoryArray.length; i++) {
          if (that.data.user.dormitoryId == that.data.dormitoryArray[i].id) {
            id = i;
          }
          that.setData({
            dormitoryIndex: id
          })
        }
      } else {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      }
    } else if (functionName == "toModify") {
      if (res.data.ifSuccess) {
        app.globalData.user = res.data.bean
        wx.setStorage({
          data: res.data.bean,
          key: 'user',
        })
        wx.navigateBack({
          delta: 1,
        })
      } else {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      }
    }
  },

  /**
   * ajax失败
   * @param {*} functionName 调用函数
   */
  callBackFail: function (functionName) {
    var that = this
    if (functionName == "onShow") {} else if (functionName == "toModify") {}
  },

  /**
   * ajax完成
   * @param {*} functionName 调用函数
   */
  callBackComplete: function (functionName) {
    var that = this
    if (functionName == "onShow") {} else if (functionName == "toModify") {}
  }
})