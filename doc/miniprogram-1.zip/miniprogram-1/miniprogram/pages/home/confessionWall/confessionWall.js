var app = getApp()
var utils = require('../../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    confessionWallList: [],
    greatList: [],
    commentList: [],

    id: 0,

    commentCount: 0, //评论的数量
    modelId: 0, //评论的标识
    ifRefreshPage: true,

    scrollTop: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(this.data.scrollTop)
  },

  /**
   * 获取告白墙
   */
  getConfessionWall: function () {
    var data = {};
    data.stuNum = app.globalData.user.stuNum;
    data.id = this.data.id
    utils.toAjax(this, "confession/selectLimit", "POST", data, "getConfessionWall");
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this
    //初始化数据
    if (this.data.modelId == 0 && this.data.ifRefreshPage) {
      this.onPullDownRefresh();
    }
    //评论后的情况，不刷新整个的数据
    if (this.data.modelId != 0) {
      var nowConfessionWallList = [];
      that.data.confessionWallList.forEach(element => {
        if (element.id == that.data.modelId) {
          element.commentCount = that.data.commentCount
        }
        nowConfessionWallList.push(element)
      });
      that.setData({
        confessionWallList: nowConfessionWallList,
        commentCount: 0,
        modelId: 0
      })
    }
    wx.getStorage({
      key: 'scrollTop',
      success: function (res) {
        console.log(res.data)
        that.setData({
          scrollTop: res.data
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    var that = this
    wx.setStorage({
      data: that.data.scrollTop,
      key: 'scrollTop',
    })
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    utils.greatSave("great/insertAll", this.data.greatList);
    wx.setStorage({
      data: 0,
      key: 'scrollTop',
    })
  },

  /**
   * 下拉刷新事件
   */
  onPullDownRefresh: function () {
    var that = this;
    that.setData({
      confessionWallList: [],
      id: 0
    })
    that.getConfessionWall();
  },

  /**
   * 触底事件
   */
  onReachBottom: function () {
    var that = this;
    that.getConfessionWall();
  },

  /**
   * 展示图片
   */
  showImage: function (e) {
    utils.showImage(e.currentTarget.dataset.src);
  },

  /**
   * 点赞
   */
  toGreat: function (e) {
    utils.toGreat(this, app.globalData.user.stuNum, "00", e.currentTarget.dataset.id);
  },

  /**
   * 评论
   */
  toComment: function (e) {
    utils.toComment(this, "00", e.currentTarget.dataset.id);
  },

  /**
   * 页面滚动
   */
  scrollItem: function (e) {
    this.setData({
      scrollTop: e.detail.scrollTop
    })
  },

  /**
   * ajax成功
   * @param {*} res 返回参数
   * @param {*} functionName 调用函数
   */
  callBackSuccess: function (res, functionName) {
    var that = this
    if (functionName == "getConfessionWall") {
      if (res.data.ifSuccess) {
        if (res.data.bean.length > 0) {
          var nowConfessionWallList = that.data.confessionWallList;
          res.data.bean.forEach(element => {
            nowConfessionWallList.push(element);
          });
          that.setData({
            confessionWallList: nowConfessionWallList,
            id: res.data.bean[res.data.bean.length - 1].id,
            scrollTop: 0
          })
        }
      } else {
        wx.showToast({
          title: '连接失败，请稍后再试！',
          icon: 'none',
          duration: 1500
        })
      }
    }
  },

  /**
   * ajax失败
   * @param {*} functionName 调用函数
   */
  callBackFail: function (functionName) {
    var that = this
    if (functionName == "getConfessionWall") {}
  },

  /**
   * ajax完成
   * @param {*} functionName 调用函数
   */
  callBackComplete: function (functionName) {
    var that = this
    if (functionName == "getConfessionWall") {}
  }
})